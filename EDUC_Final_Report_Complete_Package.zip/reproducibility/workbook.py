import json,shutil,zipfile,re,math,xml.etree.ElementTree as ET
from pathlib import Path
from openpyxl import load_workbook
from openpyxl.styles import Font,PatternFill,Alignment,Border,Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table,TableStyleInfo
from openpyxl.workbook.properties import CalcProperties
import pandas as pd,numpy as np
from build_analysis import ROOT,SOURCE,CUTOFF

OUT=ROOT/'deliverables';OUT.mkdir(exist_ok=True)
NAVY='184B77';TEAL='008A91';PALE='EEF4F8';WHITE='FFFFFF';INK='183047'
def excel_value(v):
    if v is None or (isinstance(v,(float,np.floating)) and not math.isfinite(v)):return None
    if isinstance(v,(np.integer,)):return int(v)
    if isinstance(v,(np.floating,)):return float(v)
    if isinstance(v,(np.bool_,)):return bool(v)
    if isinstance(v,str) and v.startswith(('=','+','-','@')):return "'"+v
    return v

def cache_formulas(path,cache):
    ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    with zipfile.ZipFile(path) as z:items={n:z.read(n) for n in z.namelist()}
    book=ET.fromstring(items['xl/workbook.xml']);rels=ET.fromstring(items['xl/_rels/workbook.xml.rels'])
    ids={x.attrib['Id']:x.attrib['Target'] for x in rels}
    rid='{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id'
    for sh in book.find('m:sheets',ns):
        if sh.attrib['name'] not in cache:continue
        target=ids[sh.attrib[rid]];target=target.lstrip('/') if target.startswith('/') else 'xl/'+target
        xml=ET.fromstring(items[target])
        for cell in xml.findall('.//m:c',ns):
            coord=cell.attrib['r']
            if coord in cache[sh.attrib['name']]:
                val=cell.find('m:v',ns)
                if val is None:val=ET.SubElement(cell,'{'+ns['m']+'}v')
                val.text=str(cache[sh.attrib['name']][coord]);cell.attrib.pop('t',None)
        items[target]=ET.tostring(xml,encoding='utf-8',xml_declaration=True)
    temp=path.with_suffix('.cached.xlsx')
    with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED) as z:
        for n,b in items.items():z.writestr(n,b)
    temp.replace(path)

def build_workbook():
    path=OUT/'EDUC_Analytical_Workbook_2024_2026.xlsx';shutil.copy2(SOURCE,path)
    wb=load_workbook(path);original_names=wb.sheetnames.copy();cache={};positions={}
    d=pd.read_csv(ROOT/'analytical_dataset.csv',keep_default_na=False)
    numeric=['year','estimate_numeric','student_potential_estimate','impressions','views','clicks','interactions','reach_accounts','likes','shares','saves','comments','reposts','partial_social_actions','partial_actions_per_reach_pct','click_to_impression_pct','social_interaction_to_impression_pct','combined_interaction_to_impression_pct']
    for c in numeric:d[c]=pd.to_numeric(d[c],errors='coerce')
    def sheet(name,data,note='',table=True):
        ws=wb.create_sheet(name);ws.sheet_view.showGridLines=False
        ws.cell(1,1,name.replace('_',' ')).font=Font(name='Calibri',size=16,bold=True,color=NAVY)
        ws.cell(2,1,note).font=Font(name='Calibri',size=10,italic=True,color='607383');ws.row_dimensions[2].height=29
        ws.cell(2,1).alignment=Alignment(wrap_text=True,vertical='top')
        if len(data.columns)>1:ws.merge_cells(start_row=2,start_column=1,end_row=2,end_column=min(len(data.columns),10))
        for j,c in enumerate(data.columns,1):
            x=ws.cell(4,j,str(c));x.font=Font(name='Calibri',bold=True,color=WHITE,size=10);x.fill=PatternFill('solid',fgColor=NAVY);x.alignment=Alignment(wrap_text=True,vertical='center')
            maxlen=max([len(str(c))]+[len(str(v)) for v in data[c].head(300) if str(v)!='nan'])
            ws.column_dimensions[get_column_letter(j)].width=min(60,max(14,min(maxlen+2,28)))
        ws.row_dimensions[4].height=31
        for i,values in enumerate(data.itertuples(index=False,name=None),5):
            for j,v in enumerate(values,1):
                cell=ws.cell(i,j,excel_value(v));cell.font=Font(name='Calibri',size=10,color=INK);cell.alignment=Alignment(vertical='top',wrap_text=True)
                if isinstance(v,(float,np.floating)):cell.number_format='#,##0.00;[Red]-#,##0.00'
                if i%2==0:cell.fill=PatternFill('solid',fgColor=PALE)
            ws.row_dimensions[i].height=30 if len(data)<300 else 32
        ws.freeze_panes='B5';ws.auto_filter.ref=f'A4:{get_column_letter(len(data.columns))}{max(4,4+len(data))}'
        ws.sheet_properties.pageSetUpPr.fitToPage=True;ws.page_setup.orientation='landscape';ws.page_setup.paperSize=ws.PAPERSIZE_A4;ws.page_setup.fitToWidth=1;ws.page_setup.fitToHeight=0;ws.print_title_rows='1:4'
        ws.oddFooter.center.text='EDUC II • D9.3 | &P / &N';ws.oddFooter.center.size=9
        positions[name]={'header':4,'first':5,'last':4+len(data),'columns':{str(c):j for j,c in enumerate(data.columns,1)}}
        if table and len(data):
            tb=Table(displayName='T_'+re.sub('[^A-Za-z0-9_]','_',name),ref=ws.auto_filter.ref);tb.tableStyleInfo=TableStyleInfo(name='TableStyleMedium2',showRowStripes=True);ws.add_table(tb)
        return ws
    readme=pd.DataFrame([
        ('Purpose','Comprehensive EDUC II D9.3 analysis: activity, performance, KPI and impact evidence.'),
        ('Snapshot','2024-01-01 to 2026-11-16; future dates and explicit undated plans are excluded from observed performance.'),
        ('Source preservation','The four original source worksheets are retained with their original names, values and formulas. All new analysis is on added sheets.'),
        ('Headline population','2,855 activity-like source records; 2,236 eligible gross records; 23 duplicate reports removed; 2,213 retained records.'),
        ('Calendar','30 eligible calendar entries are analysed separately and reconciled as candidates; they are not added to the core count.'),
        ('Unique outputs','Publication_identifiers and Content_groups supply identifiable-output proxies. Unresolved identifiers and cross-platform creative reuse prevent a definitive total of unique productions.'),
        ('Metrics','Labelled LinkedIn impressions/clicks/interactions are separate from the heterogeneous Estimated number of persons reached field and from user-supplied website analytics.'),
        ('Student exposure','Largest single explicitly student-directed email audience estimate per year; never sum overlapping audiences to claim unique students.'),
        ('Topics and audiences','Primary categories support additive totals; secondary/multiple labels overlap. Intended audiences are inferred where appropriate, not measured demographics.'),
        ('KPI assessment','Read KPI_matrix for all 29 commitments, including functional equivalence, evidence types and final validation items.'),
        ('Recalculation','Formula_Audit and Annual contain live Excel formulas with cached results. Re-run the supplied Python pipeline to rebuild classifications and static cross-tabulations.'),
        ('Source links','Analytical record IDs C/L/D + original Excel row are stable. source_reference cells link directly to original worksheets.'),
        ('Source integrity','See input SHA-256 in the methodology annex and validation manifest. Uploaded originals are unchanged.'),
    ],columns=['Item','Explanation'])
    ws=sheet('START_HERE',readme,table=False);ws.column_dimensions['A'].width=24;ws.column_dimensions['B'].width=115
    for i in range(5,5+len(readme)):ws.row_dimensions[i].height=45
    inputws=wb.create_sheet('Inputs');inputws.append(['Parameter','Value','Definition / validation'])
    inp=[['Snapshot',str(CUTOFF),'Europe/Budapest client date'],['Start','2024-01-01','User reporting scope'],['Website source','User-supplied Google Analytics','Period and view definition to validate'],['Website views',245619,'User-confirmed supplied figure'],['Website target',75000,'Grant §3.2 p.66'],['Website excess',170619,'Views above original target'],['Latest newsletter estimated audience',1910,'C1429; estimated audience, not verified subscribers'],['Newsletter subscriber target',1500,'Grant §3.2 p.66'],['Student potential exposure target',6000,'Estimated exposure method in Student_potential'],['Original workbook SHA256',__import__('hashlib').sha256(SOURCE.read_bytes()).hexdigest(),'Integrity reference']]
    for row in inp:inputws.append(row)
    for col,w in [('A',40),('B',76),('C',80)]:inputws.column_dimensions[col].width=w
    for c in inputws[1]:c.fill=PatternFill('solid',fgColor=NAVY);c.font=Font(bold=True,color=WHITE)
    inputws.freeze_panes='B2'
    ws=sheet('Analytical',d,'All 2,855 source records retained. Filter eligible_net = TRUE for the core 2024–2026 analysis. Missing analytics never cause exclusion.')
    for c in ['description','outcome','quality_flags','audience_rule','url_raw','source_reference']:
        ws.column_dimensions[get_column_letter(list(d.columns).index(c)+1)].width=65
    refcol=list(d.columns).index('source_reference')+1
    for i,r in enumerate(d.itertuples(index=False),5):
        c=ws.cell(i,refcol);c.hyperlink=f"#'{r.sheet}'!C{int(r.source_row)}";c.style='Hyperlink'
    cal=pd.read_csv(ROOT/'event_calendar_clean.csv',keep_default_na=False)
    sheet('Calendar_analysis',cal,'Calendar entries are complementary event evidence; potential overlaps are listed, not automatically added to activity totals.')
    files=['Annual','Matched_period','Monthly','Quarterly','Platform_year','Platform_month','Platform_quarter','Matched_platforms','Matched_months','Visibility_platform','Annual_visibility','Labelled_metrics_posts','Instagram_case','Metrics_year','Metrics_month','Metrics_topic','Metrics_format','Topic_year','Topic_month','Topic_platform','Topic_audience','Topic_visibility','Audience_year','Audience_month','Audience_platform','Audience_coverage','Audience_metrics','University_subgroups','Partner_year','Format_year','Format_platform','Channel_year','Output_indicators','Offers_monthly','Offer_family_records','Student_potential','Weekly_cadence','Newsletter_issue_groups','Publication_identifiers','Content_groups','KPI_matrix','Evidence_register']
    notes={'Audience_coverage':'Multi-label activity coverage: totals/percentages overlap and must not be summed as exclusive groups.','Student_potential':'Estimated potential student exposure. Single-channel maximum avoids summing overlapping audiences; no verified unique-person claim.','KPI_matrix':'Achievement percentages can be exact, functional-equivalent, cumulative-only or estimated proxies; read Evidence_type and Calculation_method.','Visibility_platform':'Gross_estimate is a heterogeneous source-field sum, not unique reach or a comparable platform metric. Labelled metrics are reported separately.','Metrics_year':'Observed LinkedIn cohorts differ in coverage; do not interpret cohort differences as alliance-wide engagement growth.','Offers_monthly':'Distinct named programme families are a conservative proxy for unique offers. November 2026 is partial.','Content_groups':'Working identifiable-content groups; not a certified inventory of unique creative productions. Unidentified records are retained in Analytical.'}
    for n in files:
        t=pd.read_csv(ROOT/(n+'.csv'),keep_default_na=False)
        ws=sheet(n,t,notes.get(n,'Recalculated from eligible_net activity records; see methodology annex and Analytical source links.'))
        if n=='KPI_matrix':
            for j in range(1,len(t.columns)+1):ws.column_dimensions[get_column_letter(j)].width=45 if j>1 else 12
            for i in range(5,5+len(t)):ws.row_dimensions[i].height=110
    last=positions['Analytical']['last'];cols=positions['Analytical']['columns']
    rng=lambda c:f"Analytical!${get_column_letter(cols[c])}$5:${get_column_letter(cols[c])}${last}"
    # Live annual output formulas, with cached values for read-only previews.
    aw=wb['Annual'];adata=pd.read_csv(ROOT/'Annual.csv')
    for i,r in enumerate(adata.itertuples(index=False),5):
        for c in ['Central','Dissemination','Local']:
            j=positions['Annual']['columns'][c];cell=aw.cell(i,j)
            cell.value=f'=COUNTIFS({rng("eligible_net")},TRUE,{rng("year")},$A{i},{rng("register")},"{c}")'
            cache.setdefault('Annual',{})[cell.coordinate]=int(getattr(r,c))
        j=positions['Annual']['columns']['Total'];cell=aw.cell(i,j);cell.value=f'=SUM(B{i}:D{i})';cache['Annual'][cell.coordinate]=int(r.Total)
    q=d[d.eligible_net];e=q[q.impressions.notna()]
    checks=[
        ('Eligible gross records',f'=COUNTIF({rng("eligible_gross")},TRUE)',int(d.eligible_gross.sum())),
        ('Retained records',f'=COUNTIF({rng("eligible_net")},TRUE)',len(q)),
        ('Duplicate reports removed',f'=COUNTIF({rng("eligible_gross")},TRUE)-COUNTIF({rng("eligible_net")},TRUE)',int((d.eligible_gross & ~d.eligible_net).sum())),
        ('Website target attainment (%)','=Inputs!B5/Inputs!B6*100',327.492),
        ('Latest newsletter audience proxy (%)','=Inputs!B8/Inputs!B9*100',1910/1500*100),
        ('Social-media publications',f'=COUNTIFS({rng("eligible_net")},TRUE,{rng("channel")},"Social media")',int(q.channel.eq('Social media').sum())),
        ('Labelled LinkedIn impressions',f'=SUMIFS({rng("impressions")},{rng("eligible_net")},TRUE)',float(e.impressions.sum())),
        ('Labelled LinkedIn clicks',f'=SUMIFS({rng("clicks")},{rng("eligible_net")},TRUE)',float(e.clicks.sum())),
        ('Labelled LinkedIn social interactions',f'=SUMIFS({rng("interactions")},{rng("eligible_net")},TRUE)',float(e.interactions.sum())),
        ('Gross audience-value sum (not unique reach)',f'=SUMIFS({rng("estimate_numeric")},{rng("eligible_net")},TRUE)',float(q.estimate_numeric.sum())),
        ('Matched 2025 records',f'=COUNTIFS({rng("eligible_net")},TRUE,{rng("matched_2025_2026")},TRUE,{rng("year")},2025)',int((q.matched_2025_2026 & q.year.eq(2025)).sum())),
        ('Matched 2026 records',f'=COUNTIFS({rng("eligible_net")},TRUE,{rng("matched_2025_2026")},TRUE,{rng("year")},2026)',int((q.matched_2025_2026 & q.year.eq(2026)).sum())),
    ]
    ws=sheet('Formula_Audit',pd.DataFrame([(a,'',v,'') for a,f,v in checks],columns=['Indicator','Excel_formula_result','Python_baseline','Difference']),'Live formulas recalculate in Excel; cached results are supplied for previews. Differences should be zero.',table=False)
    for i,(_,f,v) in enumerate(checks,5):
        ws.cell(i,2,f);ws.cell(i,4,f'=B{i}-C{i}');cache.setdefault('Formula_Audit',{}).update({f'B{i}':v,f'D{i}':0})
    ws.column_dimensions['A'].width=45
    for c in ['B','C','D']:ws.column_dimensions[c].width=25
    kp=wb['KPI_matrix'];k=pd.read_csv(ROOT/'KPI_matrix.csv')
    for id,f,v in [('K01','=Inputs!B5/Inputs!B6*100',327.492),('K02','=Inputs!B8/Inputs!B9*100',1910/1500*100)]:
        ix=int(k.index[k.KPI_ID.eq(id)][0])+5;j=positions['KPI_matrix']['columns']['Achievement_pct'];c=kp.cell(ix,j,f);cache.setdefault('KPI_matrix',{})[c.coordinate]=v
    # Navigation order: original source tabs stay intact at the end.
    new=[s for s in wb.worksheets if s.title not in original_names];orig=[wb[n] for n in original_names]
    wb._sheets=new+orig
    wb.calculation=CalcProperties(calcId=191029,fullCalcOnLoad=True,forceFullCalc=True,calcMode='auto')
    wb.save(path);cache_formulas(path,cache)
    # Validate original populated cell values/formulas survive the analytical workbook assembly.
    src=load_workbook(SOURCE,data_only=False);dest=load_workbook(path,data_only=False)
    compared=0
    for s in src:
        ds=dest[s.title]
        for row in s.iter_rows():
            for c in row:
                if c.value is not None:
                    assert ds.cell(c.row,c.column).value==c.value,(s.title,c.coordinate)
                    compared+=1
    cached=load_workbook(path,data_only=True)
    assert abs(cached['KPI_matrix']['E5'].value-327.492)<1e-8
    (ROOT/'workbook_validation.json').write_text(json.dumps({'source_populated_cells_compared':compared,'original_cell_values_and_formulas_preserved':True,'formula_cache_checks_passed':True,'sheet_count':len(dest.sheetnames),'output':path.name},indent=2))
    print(path, 'sheets',len(dest.sheetnames),'original cells verified',compared)
    return path

if __name__=='__main__':build_workbook()
