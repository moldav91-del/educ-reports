import json,re,calendar
from pathlib import Path
import pandas as pd
import numpy as np
from build_analysis import ROOT, clean,norm,AUDIENCES,TOPICS

def records(df):return json.loads(df.to_json(orient='records',force_ascii=False))
def enrich():
    d=pd.read_csv(ROOT/'analytical_dataset.csv',keep_default_na=False)
    numeric=['year','estimate_numeric','student_potential_estimate','impressions','views','clicks','interactions','reach_accounts','likes','shares','saves','comments','reposts','partial_social_actions','partial_actions_per_reach_pct','click_to_impression_pct','social_interaction_to_impression_pct','combined_interaction_to_impression_pct']
    for c in numeric:d[c]=pd.to_numeric(d[c],errors='coerce')
    q=d[d.eligible_net].copy();q.year=q.year.astype(int)
    curation=json.loads((ROOT/'curation.json').read_text())
    d['blog_equivalent_reviewed']=d.record_id.isin(sum(curation['blog_equivalents'].values(),[]))
    d['expert_output_reviewed']=d.record_id.isin(sum(curation['expert_knowledge_outputs'].values(),[]))
    d['roundtable_reviewed']=d.record_id.isin(sum(curation['roundtable_engagement'].values(),[]))
    d['policy_paper_reviewed']=d.record_id.isin(sum(curation['policy_papers'].values(),[]))
    # Conservative inference of targeted calls communicated by email, excluding routine editions.
    d['mailing_functional_candidate']=d.mailing_campaign | (d.channel.eq('Email / newsletter') & ~d.newsletter_edition & (d.title+' '+d.description).map(lambda s:bool(re.search(r'call|language programme|among faculties|internal promotion',norm(s)))))
    q=d[d.eligible_net].copy();q.year=q.year.astype(int)
    for ids in sum([list(curation[k].values()) for k in ['blog_equivalents','expert_knowledge_outputs','roundtable_engagement','policy_papers']],[]):
        assert q.record_id.isin(ids).sum()==len(ids),('Missing curated evidence',ids)
    tabs={}
    annual=q.groupby(['year','register']).size().unstack(fill_value=0)
    annual['Total']=annual.sum(axis=1);tabs['Annual']=annual.reset_index()
    matched=q[q.matched_2025_2026].groupby(['year','register']).size().unstack(fill_value=0)
    matched['Total']=matched.sum(axis=1);tabs['Matched_period']=matched.reset_index()
    monthly=q[q.temporal_eligible].groupby(['month','register']).size().unstack(fill_value=0)
    monthly['Total']=monthly.sum(axis=1);tabs['Monthly']=monthly.reset_index()
    tabs['Quarterly']=q[q.temporal_eligible].groupby(['quarter','register']).size().unstack(fill_value=0).reset_index()
    tabs['Platform_quarter']=q[q.temporal_eligible].groupby(['quarter','platform_group']).size().unstack(fill_value=0).reset_index()
    for col,name in [('platform_group','Platform_year'),('topic_primary','Topic_year'),('audience_primary','Audience_year'),('format','Format_year'),('channel','Channel_year')]:
        x=q.groupby([col,'year']).size().unstack(fill_value=0);x['Total']=x.sum(axis=1);x['Share_pct']=x.Total/len(q)*100
        tabs[name]=x.reset_index().sort_values('Total',ascending=False)
    for col,name in [('platform_group','Platform_month'),('topic_primary','Topic_month'),('audience_primary','Audience_month')]:
        tabs[name]=q[q.temporal_eligible].groupby(['month',col]).size().unstack(fill_value=0).reset_index()
    for row,col,name in [('topic_primary','platform_group','Topic_platform'),('topic_primary','audience_primary','Topic_audience'),('audience_primary','platform_group','Audience_platform'),('format','platform_group','Format_platform')]:
        tabs[name]=pd.crosstab(q[row],q[col]).reset_index()
    # Multi-label coverage tables; percentages deliberately non-additive.
    rows=[]
    for group in AUDIENCES:
        z=q[q.audience_tags.str.contains(group,regex=False)]
        rows.append({'Audience':group,'Activities':len(z),'Share_pct':100*len(z)/len(q),**{str(y):int(z.year.eq(y).sum()) for y in [2024,2025,2026]}})
    tabs['Audience_coverage']=pd.DataFrame(rows)
    rows=[]
    for group in ['Students','Teaching staff','Researchers','Administrative and professional staff','University leadership']:
        z=q[q.university_subgroups.str.contains(group,regex=False)]
        rows.append({'Subgroup':group,'Activities':len(z),'Share_pct':100*len(z)/len(q),**{str(y):int(z.year.eq(y).sum()) for y in [2024,2025,2026]}})
    tabs['University_subgroups']=pd.DataFrame(rows)
    x=q[q.register!='Central'].groupby(['partner','register','year']).size().unstack(fill_value=0).reset_index()
    tabs['Partner_year']=x
    x=q.groupby('platform_group').agg(Activities=('record_id','size'),Estimate_records=('estimate_numeric','count'),Gross_estimate=('estimate_numeric','sum'),Labelled_impression_posts=('impressions','count'),Impressions=('impressions','sum'),Click_posts=('clicks','count'),Clicks=('clicks','sum'),Interactions=('interactions','sum'),View_posts=('views','count'),Labelled_views=('views','sum')).reset_index()
    x['Estimate_coverage_pct']=100*x.Estimate_records/x.Activities
    x['Mean_reported_estimate']=x.Gross_estimate/x.Estimate_records.replace(0,np.nan)
    x['Mean_impressions_per_observed_post']=x.Impressions/x.Labelled_impression_posts.replace(0,np.nan)
    x['Click_to_impression_pct']=100*x.Clicks/x.Impressions.replace(0,np.nan)
    x['Social_interaction_to_impression_pct']=100*x.Interactions/x.Impressions.replace(0,np.nan)
    x['Combined_interaction_to_impression_pct']=100*(x.Clicks+x.Interactions)/x.Impressions.replace(0,np.nan)
    for c in ['Impressions']:
        x.loc[x.Labelled_impression_posts.eq(0),c]=np.nan
    for c in ['Clicks','Interactions']:x.loc[x.Click_posts.eq(0),c]=np.nan
    x.loc[x.View_posts.eq(0),'Labelled_views']=np.nan
    x.loc[x.Estimate_records.eq(0),'Gross_estimate']=np.nan
    for field in ['reach_accounts','likes','shares','saves','partial_social_actions']:
        g=q.groupby('platform_group')[field].agg(lambda v:v.sum(min_count=1))
        x['Reported_'+field]=x.platform_group.map(g)
    tabs['Visibility_platform']=x
    case=q[q.reach_accounts.notna()]
    tabs['Instagram_case']=case[['record_id','date_start','platform_group','title','views','reach_accounts','likes','shares','saves','partial_social_actions','partial_actions_per_reach_pct','canonical_url']]
    for col,name in [('year','Annual_visibility'),('audience_primary','Audience_metrics'),('topic_primary','Topic_visibility')]:
        x=q.groupby(col).agg(Records=('record_id','size'),Audience_value_records=('estimate_numeric','count'),Gross_audience_value_sum=('estimate_numeric','sum'),Labelled_posts=('impressions','count'),Impressions=('impressions','sum'),Clicks=('clicks','sum'),Social_interactions=('interactions','sum')).reset_index()
        for c in ['Impressions','Clicks','Social_interactions']:x.loc[x.Labelled_posts.eq(0),c]=np.nan
        tabs[name]=x
    metric=q[q.impressions.notna()]
    allmetrics=q[q.metrics_source.ne('')]
    tabs['Labelled_metrics_posts']=allmetrics[['record_id','date_start','year','month','platform_group','topic_primary','format','impressions','views','clicks','interactions','reach_accounts','likes','shares','saves','partial_social_actions','partial_actions_per_reach_pct','click_to_impression_pct','social_interaction_to_impression_pct','combined_interaction_to_impression_pct','canonical_url']]
    for col,name in [('year','Metrics_year'),('month','Metrics_month'),('topic_primary','Metrics_topic'),('format','Metrics_format')]:
        x=metric.groupby(col).agg(Posts=('record_id','size'),Impressions=('impressions','sum'),Views=('views','sum'),Clicks=('clicks','sum'),Interactions=('interactions','sum')).reset_index()
        x['Mean_impressions']=x.Impressions/x.Posts
        x['Mean_interactions']=x.Interactions/x.Posts
        x['Click_to_impression_pct']=100*x.Clicks/x.Impressions
        x['Social_interaction_to_impression_pct']=100*x.Interactions/x.Impressions
        x['Combined_interaction_to_impression_pct']=100*(x.Clicks+x.Interactions)/x.Impressions
        tabs[name]=x
    # Fully matched monthly comparisons (November ends on day 16 in each year).
    x=q[q.matched_2025_2026].copy();x['month_number']=x.month.str[-2:].astype(int)
    x=x.groupby(['month_number','year']).size().unstack(fill_value=0)
    x['Absolute_change']=x[2026]-x[2025];x['Change_pct']=100*x.Absolute_change/x[2025].replace(0,np.nan)
    tabs['Matched_months']=x.reset_index()
    x=q[q.matched_2025_2026].groupby(['platform_group','year']).size().unstack(fill_value=0)
    for y in [2025,2026]:
        if y not in x:x[y]=0
    x['Absolute_change']=x[2026]-x[2025];x['Change_pct']=100*x.Absolute_change/x[2025].replace(0,np.nan)
    tabs['Matched_platforms']=x.reset_index()
    # Named programme family promotions, de-duplicated within month; proxy for two offers/month.
    offerrows=[]
    for _,r in q[q.offer_promotion & q.month.ne('')].iterrows():
        for fam in r.offer_families.split(' | '):
            if fam:offerrows.append({'record_id':r.record_id,'month':r.month,'year':r.year,'Offer_family':fam,'student_targeted':r.student_targeted})
    offers=pd.DataFrame(offerrows)
    tabs['Offer_family_records']=offers
    x=offers.groupby('month').agg(Promotion_records=('record_id','nunique'),Distinct_offer_families=('Offer_family','nunique')).reset_index()
    x['Benchmark_two_offers']=x.Distinct_offer_families>=2
    x['Period_status']=np.where(x.month.eq('2026-11'),'Partial month','Completed month')
    tabs['Offers_monthly']=x
    stu=[]
    for y,z in q.groupby('year'):
        a=z[z.student_distribution_candidate & ~z.interval_in_progress & z.estimate_numeric.notna()].sort_values('estimate_numeric',ascending=False)
        if len(a):
            r=a.iloc[0];stu.append(dict(year=y,Potential_student_exposure=r.estimate_numeric,Target=6000,Proxy_attainment_pct=100*r.estimate_numeric/6000,Evidence=r.record_id,Method='Largest single explicitly student-directed email audience estimate; no summation across overlapping audiences'))
    tabs['Student_potential']=pd.DataFrame(stu)
    counts=[]
    for y,z in q.groupby('year'):
        for label,mask in [('Social publications',z.channel.eq('Social media')),('Website records',z.channel.eq('Website')),('Website news URL records',z.website_news),('Newsletter edition records',z.newsletter_edition),('Explicit mailing records',z.mailing_campaign),('Functional targeted mailing candidates',z.mailing_functional_candidate),('Press / media records',z.channel.eq('Press / media article')),('Audiovisual evidence records',z.av_evidence),('Short-form video / reel records',z.format.eq('Short-form video / reel')),('Podcast-related records',z.podcast_related),('Campaign-mentioned records',z.campaign_mention),('Offer-promotion records',z.offer_promotion),('Event / dissemination records',z.channel.isin(['Event activity','Dissemination activity'])),('Explicit amplification records',z.secondary_amplification),('Reviewed blog equivalents',z.blog_equivalent_reviewed),('Reviewed expert outputs',z.expert_output_reviewed),('Roundtable engagement evidence',z.roundtable_reviewed),('Identified policy papers',z.policy_paper_reviewed)]:
            counts.append(dict(Indicator=label,year=y,Count=int(mask.sum())))
    tabs['Output_indicators']=pd.DataFrame(counts).pivot(index='Indicator',columns='year',values='Count').reset_index()
    pubs=q[q.publication_id.ne('')].groupby(['publication_id','canonical_url']).agg(Records=('record_id','size'),First_recorded_date=('date_start','min'),Years=('year',lambda x:' | '.join(map(str,sorted(set(x))))),Evidence=('record_id',lambda x:' | '.join(x))).reset_index()
    tabs['Publication_identifiers']=pubs
    groups=q[q.content_group_id.ne('')].groupby('content_group_id').agg(Records=('record_id','size'),Method=('content_group_method','first'),Evidence=('record_id',lambda x:' | '.join(x)),First_recorded_date=('date_start','min')).reset_index()
    tabs['Content_groups']=groups
    d.to_csv(ROOT/'analytical_dataset.csv',index=False)
    (ROOT/'tables.json').write_text(json.dumps({k:records(v) for k,v in tabs.items()},ensure_ascii=False,indent=2))
    for k,v in tabs.items():v.to_csv(ROOT/(k+'.csv'),index=False)
    return d,q,tabs

if __name__=='__main__':
    d,q,t=enrich()
    for k in ['Output_indicators','Matched_period','Student_potential','Metrics_topic','Metrics_format']:
        print('\n'+k);print(t[k].to_string(index=False))
