"""Run from the reproducibility directory of the EDUC package."""
import os,sys,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
source=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root.parent/'inputs/EDUC Communication_Dissemination Report (1).xlsx'
os.environ['EDUC_SOURCE_XLSX']=str(source)
os.environ['MPLCONFIGDIR']=str(root/'matplotlib-cache')
for script in ['build_analysis.py','enrich.py','build_kpis.py','charts.py','reports.py','workbook.py','validate.py']:
    subprocess.run([sys.executable,str(root/script)],check=True,env=os.environ)
print('Completed. Office deliverables are in',root/'deliverables')
