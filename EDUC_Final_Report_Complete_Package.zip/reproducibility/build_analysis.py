"""Reproducible EDUC communication analysis. Source files are read, never edited."""
import base64, calendar, collections, datetime as dt, hashlib, json, math, os, re, unicodedata
from pathlib import Path
from urllib.parse import urlparse, parse_qs, unquote, urlencode
import pandas as pd
import numpy as np
from openpyxl import load_workbook
from openpyxl.utils.datetime import from_excel

ROOT=Path(__file__).resolve().parent
BASE=ROOT.parents[1]
SOURCE=Path(os.environ.get('EDUC_SOURCE_XLSX',BASE/'attachments/bf8789fd-4e7f-46fe-9548-9470163ce684/EDUC Communication_Dissemination Report (1).xlsx'))
CUTOFF=dt.date(2026,11,16)
START=dt.date(2024,1,1)
MONTHS={m.lower():i for i in range(1,13) for m in [calendar.month_name[i],calendar.month_abbr[i]]}
MONTHS.update({'jan':1,'feb':2,'marc':3,'apr':4,'maj':5,'juni':6,'juli':7,'szept':9,'okt':10})

def clean(v):
    if v is None:return ''
    return re.sub(r'\s+',' ',str(v).replace('\xa0',' ')).strip()
def norm(v):
    return ''.join(c for c in unicodedata.normalize('NFKD',clean(v).lower()) if not unicodedata.combining(c))
def digest(v):return hashlib.sha256(v.encode()).hexdigest()[:14]
def number(v):
    if isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v):return float(v)
    s=clean(v)
    if re.fullmatch(r'\d+(?:[.,]\d+)?',s):return float(s.replace(',','.'))
    if re.fullmatch(r'\d{1,3}(?:[, ]\d{3})+',s):return float(s.replace(',','').replace(' ',''))
    return None
def mk(y,m,d):
    try:return dt.date(int(y),int(m),int(d))
    except (ValueError,TypeError):return None

def parse_date(v):
    """Return start, end, precision, rule. Only explicit dates are primary evidence."""
    if isinstance(v,dt.datetime):return v.date(),v.date(),'day','Excel datetime'
    if isinstance(v,dt.date):return v,v,'day','Excel date'
    if isinstance(v,(int,float)) and 40000<v<50000:
        d=from_excel(v).date();return d,d,'day','Excel serial'
    s=norm(v).replace('–','-').replace('—','-').strip(' .')
    if not s:return None,None,'missing','No date'
    if 'planned' in s or 'not yet' in s:return None,None,'planned','Undated plan'
    s=re.sub(r'\s*\(in person,.*\)$','',s).strip()
    # Other explicit source formats, retained with their stated precision.
    m=re.fullmatch(r'(\d{1,2})\.(\d{1,2})\.?\s*-\s*(\d{1,2})\.(\d{1,2})\.(\d{2,4})',s)
    if m:
        y=int(m[5])+(2000 if len(m[5])==2 else 0)
        return mk(y,m[2],m[1]),mk(y,m[4],m[3]),'range','Cross-month day interval'
    m=re.fullmatch(r'([a-z]+)\s+(\d{1,2})\s*-\s*([a-z]+)\s+(\d{1,2})\s+(20\d{2})',s)
    if m and m[1] in MONTHS and m[3] in MONTHS:
        return mk(m[5],MONTHS[m[1]],m[2]),mk(m[5],MONTHS[m[3]],m[4]),'range','Named cross-month interval'
    m=re.fullmatch(r'([a-z]+),\s*(\d{1,2})(?:\s*-\s*(\d{1,2}))?(?:\s*-\s*(\d{1,2}))?\s+(20\d{2})',s)
    if m and m[1] in MONTHS:
        ds=[int(v) for v in m.groups()[1:4] if v]
        return mk(m[5],MONTHS[m[1]],min(ds)),mk(m[5],MONTHS[m[1]],max(ds)),'range' if len(ds)>1 else 'day','Named day list / single date'
    m=re.fullmatch(r'(20\d{2})\.\s*([a-z]+)\s+([\d, ]+)',s)
    if m and m[2] in MONTHS:
        ds=[int(v) for v in re.findall(r'\d+',m[3])]
        return mk(m[1],MONTHS[m[2]],min(ds)),mk(m[1],MONTHS[m[2]],max(ds)),'range' if len(ds)>1 else 'day','Year-first named day list'
    m=re.fullmatch(r'(\d{1,2})\.(\d{1,2})\.-(\d{1,2})\.(\d{1,2})\.(20\d{2})',s)
    if m:return mk(m[5],m[2],m[1]),mk(m[5],m[4],m[3]),'range','Explicit cross-month interval'
    m=re.fullmatch(r'(20\d{2})\.\s*([a-z]+)\s+(\d{1,2})-([a-z]+)\s+(\d{1,2})',s)
    if m and m[2] in MONTHS and m[4] in MONTHS:return mk(m[1],MONTHS[m[2]],m[3]),mk(m[1],MONTHS[m[4]],m[5]),'range','Year-first named cross-month interval'
    # Paired full dates, e.g. 31.01.2024 to 02.02.2024; use actual interval.
    full=re.findall(r'(?<!\d)(\d{1,2})[./](\d{1,2})[./](\d{2,4})(?!\d)',s)
    if full and (len(full)>1 or re.search(r'from|\bto\b| - |\d{2,4}-\d',s)):
        ds=[mk(int(y)+(2000 if len(y)==2 else 0),m,d) for d,m,y in full]
        ds=[d for d in ds if d]
        if len(ds)>1:return min(ds),max(ds),'range','Explicit date interval'
    # Same month day range: 8-12/06/2026, 9.-13.11.2026, 20-22.10.2025.
    m=re.fullmatch(r'(\d{1,2})\.?\s*-\s*(\d{1,2})[./](\d{1,2})[./](\d{2,4})',s)
    if m:
        a,b,mo,y=m.groups();y=int(y)+(2000 if len(y)==2 else 0)
        return mk(y,mo,a),mk(y,mo,b),'range','Same-month day interval'
    # Year-first numerical / textual dates and year-first ranges.
    m=re.fullmatch(r'(20\d{2})[./-]\s*(\d{1,2})[./-]\s*(\d{1,2})(?:\s*-\s*(\d{1,2}))?',s)
    if m:
        y,mo,a,b=m.groups();d=mk(y,mo,a)
        return d,mk(y,mo,b) if b else d,'range' if b else 'day','Year-first numerical'
    m=re.fullmatch(r'(20\d{2})\.\s*([a-z]+)\.?\s+(\d{1,2})(?:\s*-\s*(\d{1,2}))?',s)
    if m and m[2] in MONTHS:
        d=mk(m[1],MONTHS[m[2]],m[3]);e=mk(m[1],MONTHS[m[2]],m[4]) if m[4] else d
        return d,e,'range' if m[4] else 'day','Year-first named month'
    # First day has explicit date, explanatory text follows (not arbitrary inferred dates).
    for fmt in ['%d/%m/%Y','%d.%m.%Y','%d/%m/%y','%d.%m.%y','%Y-%m-%d','%Y/%m/%d']:
        try:d=dt.datetime.strptime(s,fmt).date();return d,d,'day','Explicit numerical date'
        except ValueError:pass
    m=re.fullmatch(r'(\d{1,2})\s+([a-z]+)\s+(20\d{2})',s)
    if m and m[2] in MONTHS:
        d=mk(m[3],MONTHS[m[2]],m[1]);return d,d,'day','Day named-month year'
    # Named multi-day meeting, e.g. April 10-12 2024; named discrete days use range envelope.
    m=re.fullmatch(r'([a-z]+)\s+(\d{1,2})(?:\s*-\s*(\d{1,2}))?\s+(20\d{2})',s)
    if m and m[1] in MONTHS:
        a=mk(m[4],MONTHS[m[1]],m[2]);b=mk(m[4],MONTHS[m[1]],m[3]) if m[3] else a
        return a,b,'range' if m[3] else 'day','Named month day(s) year'
    m=re.fullmatch(r'(\d{1,2})\s+and\s+(\d{1,2})\s+([a-z]+)\s+(20\d{2})(?:\s*\(.*\))?',s)
    if m and m[3] in MONTHS:return mk(m[4],MONTHS[m[3]],m[1]),mk(m[4],MONTHS[m[3]],m[2]),'range','Two named dates (range envelope)'
    m=re.fullmatch(r'(\d{1,2})\.?\s*-\s*(\d{1,2})\.(\d{1,2})\.(\d{2,4})',s)
    if m:
        y=int(m[4])+(2000 if len(m[4])==2 else 0)
        return mk(y,m[3],m[1]),mk(y,m[3],m[2]),'range','Short day interval'
    # Explicit single date embedded in 'From ... to ...' with only one date remaining.
    m=re.fullmatch(r'(\d{1,2})\.\s*-\s*(\d{1,2})\.(\d{1,2})\.(20\d{2})',s)
    if m:return mk(m[4],m[3],m[1]),mk(m[4],m[3],m[2]),'range','Day interval'
    m=re.fullmatch(r'([a-z]+)\s+(20\d{2})',s)
    if m and m[1] in MONTHS:
        y,mo=int(m[2]),MONTHS[m[1]];return mk(y,mo,1),mk(y,mo,calendar.monthrange(y,mo)[1]),'month','Month only'
    m=re.fullmatch(r'(\d{1,2})[./](20\d{2})',s)
    if m and 1<=int(m[1])<=12:
        y,mo=int(m[2]),int(m[1]);return mk(y,mo,1),mk(y,mo,calendar.monthrange(y,mo)[1]),'month','Numerical month only'
    if re.fullmatch(r'20\d{2}',s):
        y=int(s);return mk(y,1,1),mk(y,12,31),'year','Year only'
    # Malformed annual interval 01/0124 – 31/12.24 is explicitly recoverable.
    if s=='01/0124 - 31/12.24':return mk(2024,1,1),mk(2024,12,31),'range','Documented repair: annual 2024 interval'
    return None,None,'unresolved','Ambiguous or unrecognised date'

def canonical_url(raw):
    s=clean(raw)
    if s.startswith(('/news/','/events/','/calls/')):
        s='https://www.educalliance.eu'+s
    m=re.search(r'https?://[^\s<>]+',s)
    if not m:return '', '', ''
    s=m[0].rstrip('.,;)')
    p=urlparse(s)
    if p.netloc.lower() in ['l.facebook.com','lm.facebook.com'] and p.path=='/l.php':
        s=parse_qs(p.query).get('u',[s])[0];p=urlparse(s)
    host=p.netloc.lower().replace('www.','').replace('m.facebook.com','facebook.com')
    path=unquote(p.path).rstrip('/')
    if 'youtu.be'==host:
        vid=path.strip('/');return 'https://youtube.com/watch?v='+vid,'YouTube','youtube:'+vid
    if 'youtube.com' in host:
        vid=parse_qs(p.query).get('v',[''])[0] or (path.split('/')[-1] if '/shorts/' in path or '/embed/' in path else '')
        if vid:return 'https://youtube.com/watch?v='+vid,'YouTube','youtube:'+vid
    if 'instagram.com' in host:
        story=parse_qs(p.query).get('story_media_id',[''])[0]
        if story:return 'https://instagram.com/stories/_/'+story,'Instagram','instagram-story:'+story
        m=re.search(r'/(?:p|reel|reels|tv)/([^/]+)',path)
        if m:return 'https://instagram.com/p/'+m[1],'Instagram','instagram:'+m[1]
    if 'cdninstagram.com' in host or 'fbcdn.net' in host:
        return 'https://'+host+path,'Instagram' if 'instagram' in host else '', 'asset:'+digest(path)
    if 'linkedin.com' in host:
        m=re.search(r'(?:activity[:%-]|activity%3A|activity-)(\d+)',unquote(s),re.I)
        if not m:m=re.search(r'urn:li:(?:share|ugcPost):(\d+)',unquote(s),re.I)
        if m:return 'https://linkedin.com/feed/update/urn:li:activity:'+m[1],'LinkedIn','linkedin:'+m[1]
    if 'tiktok.com' in host:
        m=re.search(r'/video/(\d+)',path)
        if m:return 'https://'+host+path,'TikTok','tiktok:'+m[1]
    plat='Facebook' if 'facebook.com' in host else 'Bluesky' if 'bsky.app' in host else 'Mastodon / federated' if host=='social.uji.es' else 'X / Twitter' if host in ['x.com','twitter.com'] else 'LinkedIn' if 'linkedin.com' in host else ''
    # Keep identity-bearing Facebook parameters; remove tracking.
    keep={k:v[0] for k,v in parse_qs(p.query).items() if k in ['story_fbid','id','fbid','v']}
    url='https://'+host+path+('?' + urlencode(sorted(keep.items())) if keep else '')
    return url,plat,('url:'+digest(url))

TOPICS={
 'Student mobility and international opportunities':r'gap.?semester|gap.?year|internship|working abroad|mobility|study abroad|studying abroad|research fellowship',
 'Education, teaching and learning':r'course|teaching|teacher|learning|pedagog|summer school|winter school|education week|educational week|curricul|e.?tandem|language exchange|employability|entrepreneurial skills|tese days',
 'Research, innovation and Open Science':r'research|open science|innovation|microbiom|seed project|seed funding|technology transfer|laborator|scientific|doctoral|phd|retreat|cleanphotocat',
 'Digital transformation and digital education':r'digital transformation|digital campus|virtual campus|think lab|digital education|artificial intelligence|\bai\b|h5p|digital learning|digital well.?being|digital course development',
 'European identity, values and citizenship':r'european identity|european values|europe day|european election|student assembly|\besa\b|citizenship|academic freedom|solidarity|ukraine|to[iy] d.europe',
 'Institutional cooperation and alliance development':r'steering committee|governance|rector|alliance development|anniversary|educ turning|educ turns|educ is turning|educ.*five|5th anniversary|european degree|kick.?off|coordination|partner days|next phase|educ iii',
 'Events, conferences and workshops':r'conference|\beaie\b|\bapaie\b|\beurie\b|\beucen\b|mellearn|event|workshop|training week|staff week|staffweek|forum|webinar|meeting',
 'Student engagement and community-building':r'community.build|student life|studentlife|student ambassador|student board|student representative|student rep\b|youth integration|\byil\b|alumni trivia|campus life|internationalstudents|christmas|weekend|summer greeting|happy new year',
 'Stakeholder cooperation and regional engagement':r'stakeholder|regional|societal|industry|business partner|brittany|rennes metropole|civil society|world trade centre|school cooperation|school teacher',
 'Project achievements, results and impact':r'project results|project achievements|deliverable|output.sharing|output sharing|best practices|best practice|lessons learnt|lessons learned|roadmap|guideline|project wraps up|project impact',
 'Sustainability and institutional embedding':r'long.term sustainability|institutional embedding|institutional change|institutional impact|friends of educ|sustainable institutional|continuation|sustainability of.*alliance',
 'General alliance awareness and promotion':r'educ|alliance|university|universit|pecs|norway|rennes',
}
def classify_topics(title,description):
    t,d=norm(title),norm(description)
    if t in ['research collaboration','learning opportunity','application promotion','community stories','alliance visibility','event promotion','mobility experience','event highlights']:
        t=''  # These export labels are not substantive evidence of the post's topic.
    scores={k:3*len(re.findall(v,t))+len(re.findall(v,d)) for k,v in TOPICS.items()}
    # A format is not automatically a topic; it wins only if substantive categories are absent.
    scores['Events, conferences and workshops']*=.35
    scores['General alliance awareness and promotion']*=.015
    if re.search(r'youth integration|\byil\b',t):scores['Student engagement and community-building']+=12
    if re.search(r'think lab|virtual campus',t):scores['Digital transformation and digital education']+=12
    if re.search(r'friends of educ',t):scores['Sustainability and institutional embedding']+=15
    if re.search(r'sustainab|climate|water purification',t) and not re.search(r'institutional|alliance|project sustainab',t):
        # Environmental sustainability is substantive education/research, not continuation evidence.
        scores['Research, innovation and Open Science']+=2
    primary=max(scores,key=scores.get)
    secondary=[k for k,v in scores.items() if v>=2 and k!=primary and k not in ['General alliance awareness and promotion','Events, conferences and workshops']]
    return primary,secondary

AUDIENCES=['University communities','Associated partners and societal stakeholders','Higher education experts and other alliances','Policymakers and public authorities','Friends of EDUC, alumni and supporters','General public and citizens']
def classify_audiences(title,description,raw):
    t=norm(title+' '+description); a=norm(raw);tags=set();sub=set();rules=[]
    mapping={'specific end-user communities':0,'research communities':0,'students':0,'citizens':5,'civil society':1,'civil sciety':1,'industry/business partner':1,'local authorities':3,'national authorities':3,'eu institutions':3,'international organizations (un, oecd)':3,'international organizations (un; oecd)':3}
    if a in mapping:tags.add(AUDIENCES[mapping[a]]);rules.append('source label')
    if 'research communit' in a:sub.add('Researchers')
    patterns={
      'Students':r'student|gap.?semester|gap.?year|youth integration|\byil\b|summer school|winter school|internship|course catalogue|course catalog|(?:online|virtual|educ) courses?|studentlife|study abroad|tese days|etandem',
      'Teaching staff':r'teacher|teaching|pedagog|faculty|curricul|educator',
      'Researchers':r'researcher|research communit|research infrastructure|research internship|phd|doctoral|postdoc|scientific|open science|seed project|retreat',
      'Administrative and professional staff':r'staff|administrative|professional development|mentoring|secondment|job shadow|international office|librar|finance',
      'University leadership':r'rector|steering committee|dean|university leadership|university management|governance',
    }
    for k,p in patterns.items():
        if re.search(p,t):sub.add(k)
    if sub:tags.add(AUDIENCES[0]);rules.append('content-based university subgroups')
    if re.search(r'friend[s]? of educ|alumni|supporter|sponsor|donor',t):tags.add(AUDIENCES[4]);rules.append('Friends/alumni content')
    if re.search(r'\beaie\b|\beurie\b|\bapaie\b|\beucen\b|mellearn|other.*alliances|european university alliances|universities worldwide|international higher education audience|higher education expert|foreu|for.eu',t):tags.add(AUDIENCES[2]);rules.append('higher education exchange content')
    if re.search(r'policymaker|ministry|ministries|government|national agenc|tempus|rectors. conference|european commission|european parliament|regulator',t):tags.add(AUDIENCES[3]);rules.append('public-policy content')
    if re.search(r'societal|stakeholder|industry|business partner|regional partner|civil society|brittany region|rennes metropole|world trade centre|community engagement',t):tags.add(AUDIENCES[1]);rules.append('societal cooperation content')
    if re.search(r'citizen|general public|science.society|europe day|researchers. night|european elections',t):tags.add(AUDIENCES[5]);rules.append('public-facing content')
    if not tags:
        if re.search(r'educ|alliance|university|universit|campus',t):tags.add(AUDIENCES[0]);rules.append('broad alliance community inference')
    # Specific intended purpose overrides a coarse/miscoded source label for primary totals.
    if re.search(r'friend[s]? of educ|alumni',norm(title)):primary=AUDIENCES[4]
    elif re.search(r'\beaie\b|\beurie\b|\bapaie\b|\beucen\b|mellearn',norm(title)):primary=AUDIENCES[2]
    elif sub:primary=AUDIENCES[0]
    elif a in mapping:primary=AUDIENCES[mapping[a]]
    else:primary=next((x for x in AUDIENCES if x in tags),'Unclassified')
    if primary!='Unclassified':tags.add(primary)
    return primary,[x for x in AUDIENCES if x in tags],sorted(sub),'; '.join(rules) or 'No supported audience assignment'

OFFER_PATTERNS={
 'Gap Semester':r'gap.?semester|gap.?year',
 'Research / Erasmus internships':r'internship|working abroad',
 'Research infrastructure access':r'research infrastructure|access.*infrastructure',
 'Seed projects':r'seed project|seed funding',
 'Student language exchange':r'student.*e.?tandem|e.?tandem.*student|etandem|linguistic program.*student',
 'Staff language exchange':r'staff.*e.?tandem|staff.*language programme|e.?tandem.*staff',
 'Staff mentoring':r'mentor|mentee',
 'Staff secondment / job shadowing':r'secondment|job shadow',
 'Staff Weeks':r'staff.?week|staff training week',
 'TESE Days':r'tese days|talents and entrepreneurial skills',
 'Youth Integration Lab':r'youth integration|\byil\b',
 'Doctoral retreat':r'doctoral.*retreat|phd.*retreat|educ retreat',
 'Critical Methodologies Summer School':r'critical methodologies',
 'Paleogeography Summer School':r'paleogeography',
 'Sport and Society Summer School':r'sport.{0,6}society',
 'French Language and Culture Summer School':r'french language.{0,8}culture',
 'Norwegian Folk Music course':r'norwegian folk music|folk music.*norway',
 'Practical Norwegian course':r'practical norwegian',
 'Initiation to Research course':r'initiation to research|introduction to research|research and critical thinking',
 'European Law course':r'european law|european union law|eu law|politics of the eu',
 'AI and Digital Marketing course':r'ai.{0,8}digital marketing',
 'Employability course':r'employability|career management',
 'Entrepreneurial Mindset course':r'entrepreneurial mindset|openup',
 'Writing Across Cultures course':r'writing across cultures',
 'Digital Well-being course':r'digital well.?being',
 'Student ambassador programme':r'ambassador programme|ambassador program|call for ambassadors|student ambassador',
 'Teacher Journey':r'teacher.s journey',
 'Education / International Teaching Week':r'education week|educational week|international teaching week',
 'Intercultural English course':r'english as a lingua franca|intercultural communication|british english',
 'Circular Economy / Bioeconomy Summer School':r'circular economy|circular bioeconomy',
 'Microcredential courses':r'microcredential|micro.credential',
 'Discover Arabic course':r'discover arabic|first alphabet steps',
 'Research Management Skills Training':r'research management skills',
 'Female Empowerment course':r'female empowerment|femaleempowerment',
 'Career Diversification course':r'career diversification|carrier diversification',
 'Community of Practice / course-development sessions':r'community of practice|global community',
 'Norwegian Traditional Music week':r'norwegian traditional music|traditional music, art and dance',
}

def platform(raw,urlplat,title,description):
    s=norm(raw)
    aliases={'linkedin':'LinkedIn','instagram':'Instagram','facebook':'Facebook','youtube':'YouTube','twitter':'X / Twitter','x':'X / Twitter','x/twitter':'X / Twitter','bluesky':'Bluesky','tiktok':'TikTok','tik tok':'TikTok','ivoox':'iVoox'}
    if urlplat:return urlplat,'URL'
    if s in aliases:return aliases[s],'Source platform'
    t=norm(title+' '+description)
    for p,rx in [('Instagram',r'instagram|\binsta\b'),('TikTok',r'tik.?tok'),('Facebook',r'facebook'),('LinkedIn',r'linkedin'),('YouTube',r'youtube'),('Bluesky',r'bluesky')]:
        if re.search(rx,t):return p,'Content inference'
    return 'Unspecified / other','Not identifiable'

def channel(r):
    s=norm(r['channel_raw']);t=norm(r['title']+' '+r['description'])
    if r['register']=='Dissemination':return 'Dissemination activity'
    if s=='social media':return 'Social media'
    if s=='website':return 'Website'
    if s=='newsletter':return 'Email / newsletter'
    if s in ['media article','article']:return 'Press / media article'
    if s=='interview':return 'Interview'
    if s=='video':return 'Video'
    if s=='press release':return 'Press release'
    if 'print' in s or s=='poster':return 'Print / campus display'
    if s=='radio':return 'Radio'
    if 'event' in s or s.startswith('event (conf') or s=='exhibition':return 'Event activity'
    if re.search(r'instagram|facebook|linkedin|bluesky|youtube|tik.?tok',t):return 'Social media'
    if re.search(r'mailing|newsletter',t):return 'Email / newsletter'
    if re.search(r'online article|newsstory|news story|website',t):return 'Website'
    if 'promoting this offer to usn teachers' in s:return 'Email / newsletter'
    return 'Unclassified channel'

def load():
    w=load_workbook(SOURCE,data_only=True)
    rows=[]; calendar_rows=[];excluded=[]
    for si,s in enumerate(w):
        for row in s.iter_rows():
            vals=[c.value for c in row]
            if not any(v is not None for v in vals[:14]):continue
            n=row[0].row
            if (si==0 and n==1) or (si==1 and n==2) or (si==2 and n==1) or (si==3 and n<=2):continue
            if si==3:
                if not clean(vals[1]):continue
                start,end,precision,drule=parse_date(vals[0])
                calendar_rows.append(dict(record_id=f'E{n:04}',sheet=s.title,source_row=n,date_raw=clean(vals[0]),date_start=str(start or ''),date_end=str(end or ''),date_precision=precision,date_rule=drule,title=clean(vals[1]),description=clean(vals[2]),format=clean(vals[3]),mode=clean(vals[4]),target=clean(vals[6]),organizer=clean(vals[7]),url=clean(vals[8]),status=clean(vals[9]),eligible=bool(start and START<=start<=CUTOFF),year=start.year if start else None))
                continue
            dis=si==2
            # A title/description is required; a worksheet divider is not an activity.
            title,desc=clean(vals[2]),clean(vals[5] if dis else vals[3])
            if not title and not desc:continue
            if isinstance(vals[2],(dt.datetime,dt.date)) and not desc:
                excluded.append((s.title,n,'Worksheet divider'));continue
            r=dict(record_id=('C','L','D')[si]+f'{n:04}',sheet=s.title,source_row=n,register=('Central','Local','Dissemination')[si],task=clean(vals[1]),title=title,description=desc,audience_raw=clean(vals[4]),channel_raw=clean(vals[3] if dis else vals[5]),platform_raw='' if dis else clean(vals[6]),date_raw=clean(vals[6] if dis else vals[7]),outcome='' if dis else clean(vals[8]),declarant=clean(vals[7] if dis else vals[9]),partner_raw=clean(vals[8] if dis else vals[10]),url_raw=clean(vals[9] if dis else vals[11]),estimate_raw=clean(vals[10] if dis else vals[12]),status=clean(vals[11] if dis else vals[13]))
            start,end,precision,drule=parse_date(vals[6] if dis else vals[7])
            r.update(date_start=str(start or ''),date_end=str(end or ''),date_precision=precision,date_rule=drule,year=start.year if start else None,month=start.strftime('%Y-%m') if start and precision!='year' else '',quarter=f'{start.year}-Q{(start.month-1)//3+1}' if start and precision!='year' else '')
            status=norm(r['status'])
            r['eligibility_reason']='Included'
            if not start:r['eligibility_reason']='Planned / undated' if precision=='planned' or status=='planned' else 'Date unresolved / missing'
            elif start.year>2030:r['eligibility_reason']='Invalid / anomalous year'
            elif start<START:r['eligibility_reason']='Before 2024'
            elif start>CUTOFF:r['eligibility_reason']='After snapshot cut-off'
            elif status in ['planned','draft','cancelled']:r['eligibility_reason']='Explicit plan / draft / cancelled'
            r['eligible_gross']=r['eligibility_reason']=='Included'
            r['interval_in_progress']=bool(end and end>CUTOFF and r['eligible_gross'])
            r['temporal_eligible']=bool(r['eligible_gross'] and precision!='year')
            r['matched_2025_2026']=bool(r['eligible_gross'] and r['year'] in [2025,2026] and precision!='year' and (start.month,start.day)<=(11,16) and (end.month,end.day)<=(11,16))
            r['estimate_numeric']=number(vals[10] if dis else vals[12])
            url,uplat,pubid=canonical_url(r['url_raw']);r.update(canonical_url=url,publication_id=pubid)
            p,prule=platform(r['platform_raw'],uplat,title,desc);r.update(platform=p,platform_rule=prule)
            partners={'pte':'PTE / Pécs','upecs':'PTE / Pécs','upecs.':'PTE / Pécs','unica':'Cagliari','muni':'Masaryk','mu':'Masaryk','up':'Potsdam','usn':'USN','upn':'Paris Nanterre','ur':'Rennes','uji':'UJI','up & unica':'Potsdam + Cagliari'}
            r['partner']=partners.get(norm(r['partner_raw']),r['partner_raw'] or ('Central EDUC' if si==0 else 'Unspecified'))
            r['publisher']='Central EDUC' if si==0 else r['partner']
            r['channel']=channel(r)
            r['platform_group']=p if r['channel'] in ['Social media','Video'] or (r['channel']=='Interview' and p!='Unspecified / other') else r['channel']
            r['topic_primary'],tags=classify_topics(title,desc);r['topic_secondary']=' | '.join(tags)
            primary,tags,sub,rule=classify_audiences(title,desc,r['audience_raw'])
            r.update(audience_primary=primary,audience_tags=' | '.join(tags),university_subgroups=' | '.join(sub),audience_rule=rule)
            text=norm(title+' '+desc)
            decoded=unquote(r['url_raw'])
            r['mp4_link']=bool(re.search(r'\.mp4(?:\?|$)',r['url_raw'],re.I))
            r['reel_evidence']=bool(re.search(r'/reels?/|\breels?\b',decoded+' '+text,re.I))
            r['podcast_related']=bool(re.search(r'podcast|educast',text))
            explicit_video=bool(re.search(r'(?:video highlighting|video featuring|youtube video|instagram video|facebook video|dissemination of a video)',text) or re.search(r'\bvideo$',norm(title)))
            r['av_evidence']=r['mp4_link'] or r['reel_evidence'] or p in ['YouTube','TikTok'] or r['channel']=='Video' or explicit_video
            if r['podcast_related']:r['format']='Podcast / podcast promotion'
            elif r['mp4_link'] or r['reel_evidence'] or p=='TikTok' or '/shorts/' in r['url_raw']:r['format']='Short-form video / reel'
            elif r['av_evidence']:r['format']='Other video / recording'
            elif r['channel']=='Interview' or 'interview' in norm(title):r['format']='Interview (modality not established)'
            elif 'story' in norm(title) or 'instagram story' in text:r['format']='Social story'
            elif r['channel']=='Website':r['format']='Website editorial / information'
            else:r['format']=r['channel']
            r['website_news']=r['channel']=='Website' and '/news/' in url
            r['website_call']=r['channel']=='Website' and '/calls/' in url
            r['mailing_campaign']=bool(r['channel']=='Email / newsletter' and re.search(r'mailing campaign|mailing to|targeted.*mail|mass email|mailing list|mailing promoting|mailing call',text))
            r['newsletter_edition']=bool(r['channel']=='Email / newsletter' and re.search(r'newsletter|bulletin',text) and not r['mailing_campaign'])
            r['campaign_mention']=bool(re.search(r'campaign|er[ae]smus.?days|friends of educ.*promot',text))
            offerkeys=[k for k,v in OFFER_PATTERNS.items() if re.search(v,text)]
            # Generic reminders/retrospectives are not necessarily calls. Explicit distribution counts as marketing.
            named_course_title=bool(re.search(r'course|summer school|winter school|training|programme',norm(title)) and not re.search(r'experience|testimonial|testimony|recap|results|interview|look back',norm(title)))
            r['offer_promotion']=bool(offerkeys and (re.search(r'promot|call|appl|register|join|opportunit|offer|catalog|invit|deadline',text) or r['website_call'] or named_course_title))
            r['offer_families']=' | '.join(offerkeys) if r['offer_promotion'] else ''
            r['student_targeted']='Students' in sub
            r['student_distribution_candidate']=bool(r['channel']=='Email / newsletter' and (re.search(r'student.*newsletter|newsletter.*student',norm(title)) or re.search(r'(?:mailing|email|newsletter) (?:sent |distributed |addressed )?to (?:all )?students|promot.{0,80}among students',text)))
            # Labelled metrics are extracted from the reported Outcome, never inferred from estimated audience.
            for key,pattern in {'impressions':r'(\d[\d,]*) impressions','views':r'(\d[\d,]*) views','clicks':r'(\d[\d,]*) clicks','interactions':r'(\d[\d,]*) reactions/comments/reposts combined','reach_accounts':r'(\d[\d,]*) accounts reached','likes':r'(\d[\d,]*) likes','shares':r'(\d[\d,]*) shares','saves':r'(\d[\d,]*) saves','comments':r'(\d[\d,]*) comments','reposts':r'(\d[\d,]*) reposts'}.items():
                m=re.search(pattern,r['outcome'],re.I);r[key]=float(m[1].replace(',','')) if m else None
            r['metrics_source']='Outcome: explicitly labelled platform metrics' if r['impressions'] is not None or r['views'] is not None or r['reach_accounts'] is not None else ''
            r['secondary_amplification']=bool(re.search(r'\brepost|re-share|reshare|reposting|shared from',text))
            r['content_role']='Explicit amplification' if r['secondary_amplification'] else 'Local distribution / origin uncertain' if si==1 else 'Central publication / origin uncertain' if si==0 else 'Dissemination / participation'
            flags=[]
            if not title:flags.append('Blank title; description retained')
            if not start:flags.append('No reliable date')
            if start and start.year>2030:flags.append('Implausible project date; original value retained')
            if precision in ['range','month','year']:flags.append('Date precision: '+precision)
            if r['interval_in_progress']:flags.append('Interval extends beyond cut-off; not completed-period analytics')
            if not r['audience_raw'] or norm(r['audience_raw'])=='other':flags.append('Audience inferred / unresolved')
            if not r['channel_raw'] or r['channel']=='Unclassified channel':flags.append('Channel inferred / unresolved')
            if start:
                m=re.search(r'/(20\d{2})-(\d{2})-(\d{2})-',url)
                if m and mk(*m.groups())!=start:flags.append('Date differs from date embedded in URL')
                years=re.findall(r'20\d{2}',title)
                if r['channel']=='Email / newsletter' and years and str(start.year) not in years:flags.append('Newsletter year differs from date field')
            r['quality_flags']=' | '.join(flags)
            r['source_reference']=f'{s.title}!'+ ('C' if not dis else 'C')+str(n)
            rows.append(r)
    df=pd.DataFrame(rows)
    # Exact duplicate reporting: same identifiable publication, same publisher/channel/platform/date.
    df['duplicate_of']='';df['duplicate_status']='Retained'
    seen={}
    for idx,r in df.iterrows():
        if not r['eligible_gross']:continue
        social_post=r['publication_id'].startswith(('linkedin:','instagram:','youtube:','tiktok:')) and '/s/' not in r['canonical_url']
        if (social_post or (r['publication_id'] and r['channel']=='Website')) and r['register']!='Dissemination':
            key=(r['publication_id'],r['publisher'],r['channel'],r['platform_group'],r['date_start'])
        else:
            # Only full identical content/date/publisher is a reliable duplicate without a URL.
            if len(r['description'])<40:continue
            key=('text',r['publication_id'],norm(r['title']),norm(r['description']),r['publisher'],r['channel'],r['platform_group'],r['date_start'],r['declarant'] if r['register']=='Dissemination' else '')
        if key in seen:
            df.at[idx,'duplicate_of']=seen[key];df.at[idx,'duplicate_status']='Exact duplicate reporting'
        else:seen[key]=r['record_id']
    df['eligible_net']=df['eligible_gross'] & df['duplicate_of'].eq('')
    # Recurring URL on another date may be another dissemination action; retain, flag for review.
    eligible=df[df.eligible_net & df.publication_id.ne('')]
    recurring=eligible.groupby(['publication_id','publisher','channel','platform_group']).filter(lambda x:len(x)>1).index
    df.loc[recurring,'duplicate_status']='Repeated publication ID; retained as dated dissemination'
    df['content_group_id']=df['publication_id']
    df['content_group_method']=np.where(df.publication_id.ne(''),'Canonical publication/asset identifier','Unresolved: no stable identifier')
    # Explicitly supported cross-platform story groups, without collapsing distribution records.
    story_rules=[
      ('microbiome-pivrn','2024',r'eli[sš]ka pivrn|eliška pivrn|exploring infant microbiome'),
      ('educast-s2-tarrosy','2024',r'tarro[só]y|tarrosy|educast season 2 launch'),
      ('salma-usn-internship','2025',r'salma tahfi|salma.s internship'),
      ('educast-lulia','2025',r'lulia|iulia'),
      ('yil-uji-march','2026',r'educ youth integration lab: 30 students'),
      ('staffweek-uji-june','2026',r'open universities: sharing practices, building networks'),
      ('educast-hilde','2026',r'hilde johnsen|let.s hear what hilde|educast season 3 launch'),
    ]
    for key,y,rx in story_rules:
        mask=df.year.eq(int(y)) & (df.title+' '+df.description).map(lambda t:bool(re.search(rx,norm(t))))
        df.loc[mask,'content_group_id']='story:'+key+'-'+y
        df.loc[mask,'content_group_method']='Manually reviewed cross-platform story rule'
    df['content_group_representative']=False
    subset=df[df.eligible_net & df.content_group_id.ne('')]
    df.loc[subset.drop_duplicates('content_group_id').index,'content_group_representative']=True
    df['student_potential_estimate']=np.where(df.student_distribution_candidate & ~df.interval_in_progress,df.estimate_numeric,np.nan)
    # Per-post rates only for explicitly labelled, aligned metrics.
    df['click_to_impression_pct']=100*df.clicks/df.impressions
    df['social_interaction_to_impression_pct']=100*df.interactions/df.impressions
    df['combined_interaction_to_impression_pct']=100*(df.clicks+df.interactions)/df.impressions
    df['partial_social_actions']=df[['likes','shares','saves','comments','reposts']].sum(axis=1,min_count=1)
    df['partial_actions_per_reach_pct']=100*df.partial_social_actions/df.reach_accounts
    cal=pd.DataFrame(calendar_rows)
    # Calendar reconciliation candidates by explicit date overlap and title similarity; no automatic merger.
    from difflib import SequenceMatcher
    cal['reconciliation_candidates']='';cal['reconciliation_status']='Separate calendar evidence; not added to activity total'
    for idx,c in cal.iterrows():
        if not c['eligible']:continue
        matches=[]
        for _,r in df[df.eligible_net & df.channel.isin(['Event activity','Dissemination activity'])].iterrows():
            if r.date_start and c.date_start<=r.date_start<=c.date_end:
                sim=SequenceMatcher(None,norm(c.title),norm(r.title)).ratio()
                if sim>.4:matches.append(r.record_id)
        cal.at[idx,'reconciliation_candidates']=' | '.join(matches)
    df.to_csv(ROOT/'analytical_dataset.csv',index=False)
    cal.to_csv(ROOT/'event_calendar_clean.csv',index=False)
    (ROOT/'excluded_nonactivity.json').write_text(json.dumps(excluded,indent=2))
    # Snapshot JSON preserves actual source values and all rows outside analysis scope.
    return df,cal

def table_records(df):return json.loads(df.to_json(orient='records',force_ascii=False))
def summaries(df,cal):
    q=df[df.eligible_net].copy()
    monthly=q[q.temporal_eligible].groupby('month').size().rename('activities').reset_index()
    annual=q.groupby(['year','register']).size().unstack(fill_value=0).reset_index()
    platforms=q.groupby(['platform_group','year']).size().unstack(fill_value=0).reset_index()
    audiences=q.groupby(['audience_primary','year']).size().unstack(fill_value=0).reset_index()
    topics=q.groupby(['topic_primary','year']).size().unstack(fill_value=0).reset_index()
    matched=q[q.matched_2025_2026].groupby(['year','register']).size().unstack(fill_value=0).reset_index()
    out={'cutoff':str(CUTOFF),'source_file':SOURCE.name,'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'source_records':len(df),'gross_eligible':int(df.eligible_gross.sum()),'net_eligible':len(q),'duplicate_records_removed':int((df.eligible_gross & ~df.eligible_net).sum()),'annual':table_records(annual),'matched':table_records(matched),'platforms':table_records(platforms),'topics':table_records(topics),'audiences':table_records(audiences),'monthly':table_records(monthly),'eligibility':df.eligibility_reason.value_counts().to_dict(),'date_precision':q.date_precision.value_counts().to_dict(),'calendar_eligible':int(cal.eligible.sum()),'calendar_years':cal[cal.eligible].groupby('year').size().to_dict(),'named_content_groups':q[q.content_group_id.ne('')].content_group_id.nunique(),'unresolved_content_records':int(q.content_group_id.eq('').sum()),'metrics':{'records':int(q.impressions.notna().sum()),'impressions':float(q.impressions.sum()),'clicks':float(q.clicks.sum()),'interactions':float(q.interactions.sum())}}
    (ROOT/'summary.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
    return out

if __name__=='__main__':
    df,cal=load();out=summaries(df,cal)
    print(json.dumps(out,ensure_ascii=False,indent=2))
