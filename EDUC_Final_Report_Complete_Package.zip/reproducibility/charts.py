import json,textwrap
from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter,PercentFormatter
from build_analysis import ROOT

BLUE='#184B77';TEAL='#008A91';GOLD='#D58B27';LIGHT='#DCE7EF';INK='#183047';GRAY='#607383'
COLORS=[BLUE,TEAL,GOLD,'#689AB7','#8C6D9E','#4F8C69','#A95E55','#9BAAB7']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':14,'axes.titleweight':'bold','axes.labelcolor':INK,'axes.edgecolor':'#CBD5DE','text.color':INK,'xtick.color':GRAY,'ytick.color':GRAY,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white','axes.facecolor':'white','savefig.facecolor':'white','figure.dpi':120})
OUT=ROOT/'charts';OUT.mkdir(exist_ok=True)
meta=[]
def tab(n):return pd.read_csv(ROOT/(n+'.csv'))
def wrap(s,n=35):return '\n'.join(textwrap.wrap(str(s),n))
def finish(fig,name,title,note):
    fig.suptitle(title,x=.05,ha='left',fontsize=16,fontweight='bold',y=.98)
    fig.text(.05,.015,wrap(note,150),ha='left',va='bottom',fontsize=8,color=GRAY)
    fig.tight_layout(rect=(.03,.08,.99,.92))
    p=OUT/(name+'.png');fig.savefig(p,dpi=300,bbox_inches='tight');plt.close(fig)
    meta.append(dict(file=p.name,title=title,note=note))
def annotate(ax,bars,fmt=lambda v:f'{v:,.0f}',horizontal=False):
    for b in bars:
        if horizontal:ax.text(b.get_width(),b.get_y()+b.get_height()/2,'  '+fmt(b.get_width()),va='center',fontsize=9)
        else:ax.text(b.get_x()+b.get_width()/2,b.get_height(),fmt(b.get_height()),ha='center',va='bottom',fontsize=10)

def make():
    d=pd.read_csv(ROOT/'analytical_dataset.csv');q=d[d.eligible_net].copy();q.year=q.year.astype(int)
    a=tab('Annual');f,ax=plt.subplots(figsize=(10,5.2));bot=np.zeros(3)
    for c,col in zip(['Central','Local','Dissemination'],[BLUE,TEAL,GOLD]):
        ax.bar(['2024','2025','2026 YTD'],a[c],bottom=bot,label=c,color=col,width=.58);bot+=a[c].to_numpy()
    for i,v in enumerate(a.Total):ax.text(i,v+10,f'{v:,}',ha='center',fontweight='bold')
    ax.set_ylim(0,max(bot)*1.15);ax.set_ylabel('Retained activity records');ax.legend(frameon=False,ncol=3,loc='upper right')
    finish(f,'01_annual_activity','A sustained communication system across three years','Source: communication workbook, recalculated. Exact duplicate reports removed; cross-posting retained. 2026 ends 16 November; 2024/2025 are full years.')
    m=tab('Monthly');f,ax=plt.subplots(figsize=(10,5.2))
    for y,col in [(2025,BLUE),(2026,TEAL)]:
        x=m[m.month.str.startswith(str(y))];ax.plot(x.month.str[-2:].astype(int),x.Total,marker='o',color=col,lw=2.5,label=str(y)+(' to 16 Nov' if y==2026 else ' full-year'))
    ax.set_xticks(range(1,13),['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']);ax.set_ylabel('Records attributed to month');ax.legend(frameon=False);ax.grid(axis='y',alpha=.2)
    finish(f,'02_monthly_trends','Monthly activity follows distinct reporting and academic cycles','2026 November is partial and December is not observed. Ranges are counted once in their start month; year-only records are excluded from monthly charts.')
    z=q[q.matched_2025_2026].copy();z['qtr']=z.month.str[-2:].astype(int).sub(1).floordiv(3).add(1)
    t=pd.crosstab(z.qtr,z.year).reindex([1,2,3,4],fill_value=0)
    f,ax=plt.subplots(figsize=(10,5.2));x=np.arange(4)
    for shift,y,col in [(-.18,2025,BLUE),(.18,2026,TEAL)]:
        b=ax.bar(x+shift,t[y],.35,label=str(y),color=col);annotate(ax,b)
    ax.set_xticks(x,['Q1','Q2','Q3','Q4 to 16 Nov']);ax.legend(frameon=False);ax.set_ylabel('Records in aligned periods')
    finish(f,'03_quarterly_comparison','Quarterly comparison uses equivalent elapsed periods','Only comparable dated records are included. Q4 is 1 October–16 November in both years; year-only and intervals extending beyond the comparison end are excluded.')
    p=tab('Platform_year').head(12).iloc[::-1];f,ax=plt.subplots(figsize=(10,6.5));b=ax.barh(p.platform_group,p.Total,color=TEAL);annotate(ax,b,horizontal=True);ax.set_xlim(0,p.Total.max()*1.2);ax.set_xlabel('Platform/channel-associated records')
    finish(f,'04_platform_distribution','Instagram, LinkedIn and the website anchor distribution','Platform-associated counts include relevant social, video and interview records. Website/email/media remain channel groups. Other small channel groups are omitted here; all appear in the workbook.')
    p=tab('Platform_year').head(8);f,ax=plt.subplots(figsize=(11,5.8));x=np.arange(len(p));width=.25
    for i,(y,col) in enumerate(zip(['2024','2025','2026'],[BLUE,TEAL,GOLD])):ax.bar(x+(i-1)*width,p[y],width,color=col,label=y+(' YTD' if y=='2026' else ''))
    ax.set_xticks(x,[wrap(t,17) for t in p.platform_group],fontsize=9);ax.set_ylabel('Recorded placements');ax.legend(frameon=False,ncol=3)
    finish(f,'05_platform_by_year','The channel mix changes while the core infrastructure persists','Full-year 2024 and 2025; 2026 to 16 November. Volumes measure logged distribution, not comparative effectiveness or unique reach.')
    f,axes=plt.subplots(1,3,figsize=(12,4.8))
    for ax,val,lab,col in zip(axes,[245619,152433,3211],['Website views\nuser-supplied GA figure','LinkedIn impressions\n110 labelled post records','Instagram views\none labelled post'],[BLUE,TEAL,GOLD]):
        b=ax.bar([0],[val],color=col,width=.5);annotate(ax,b);ax.set_xticks([0],[lab]);ax.set_ylim(0,val*1.3);ax.yaxis.set_major_formatter(FuncFormatter(lambda x,p:f'{x/1000:.0f}k'))
    finish(f,'06_visibility_indicators','Distinct visibility measures have different coverage','Separate panels have independent scales and different measures/periods. Website definition requires validation. Instagram C0704 also reports 2,237 accounts reached. These measures must not be added as unique people.')
    e=tab('Metrics_year');f,axes=plt.subplots(1,2,figsize=(10,5));x=np.arange(2)
    for ax,col,label in [(axes[0],'Click_to_impression_pct','Click-to-impression ratio'),(axes[1],'Social_interaction_to_impression_pct','Social interactions / impressions')]:
        b=ax.bar(x,e[col],color=[BLUE,TEAL],width=.6);annotate(ax,b,lambda v:f'{v:.2f}%');ax.set_xticks(x,[f'{int(r.year)}\nn={int(r.Posts)}' for _,r in e.iterrows()]);ax.set_title(label,fontsize=12);ax.set_ylim(0,e[col].max()*1.28);ax.set_ylabel('Percent')
    finish(f,'07_engagement_indicators','Observed LinkedIn engagement is measurable, with uneven coverage','Ratios are sums of labelled clicks or reactions/comments/reposts divided by labelled impressions. Cohorts differ: 16 posts in 2025 and 94 in 2026. No platform-wide trend or cross-platform ranking is inferred.')
    t=tab('Topic_year').iloc[::-1];f,ax=plt.subplots(figsize=(11,8));b=ax.barh([wrap(v,44) for v in t.topic_primary],t.Total,color=TEAL);annotate(ax,b,horizontal=True);ax.set_xlim(0,t.Total.max()*1.2);ax.set_xlabel('Records in a single primary topic')
    finish(f,'08_topic_distribution','Education, research and mobility carry the substantive offer','Deterministic content classification; one primary topic supports additive totals and secondary tags preserve overlaps. Broad awareness and event categories include content with limited thematic detail.')
    t=tab('Topic_year');mat=np.array([100*t[y]/t[y].sum() for y in ['2024','2025','2026']]).T
    f,ax=plt.subplots(figsize=(10,7.5));im=ax.imshow(mat,aspect='auto',cmap='YlGnBu');ax.set_xticks(range(3),['2024','2025','2026 YTD']);ax.set_yticks(range(len(t)),[wrap(v,43) for v in t.topic_primary],fontsize=9)
    for i in range(len(t)):
        for j in range(3):ax.text(j,i,f'{mat[i,j]:.1f}%',ha='center',va='center',color='white' if mat[i,j]>14 else INK,fontsize=9)
    f.colorbar(im,ax=ax,label='Share of annual records (%)',shrink=.7)
    finish(f,'09_topics_by_year','Topic shares reveal editorial balance and emerging priorities','Percentages refer to classified records in each year; 2026 is partial. Sustainability here means alliance continuation/embedding, not environmental sustainability research.')
    t=tab('Audience_year').iloc[::-1];f,ax=plt.subplots(figsize=(11,6));b=ax.barh([wrap(v,43) for v in t.audience_primary],t.Total,color=BLUE);annotate(ax,b,horizontal=True);ax.set_xlim(0,t.Total.max()*1.18);ax.set_xlabel('Records by primary intended audience')
    finish(f,'10_audience_distribution','University communities are the principal intended audience','Primary audience combines source labels with content and purpose. This is intended-audience coverage, not measured demographics. Multi-label coverage is separately available in the workbook.')
    t=tab('Audience_platform').set_index('audience_primary');cols=['Instagram','LinkedIn','Facebook','Website','Email / newsletter','Dissemination activity','Press / media article','Event activity'];t=t[cols]
    f,ax=plt.subplots(figsize=(11,6));mat=t.to_numpy();im=ax.imshow(np.log1p(mat),aspect='auto',cmap='YlGnBu');ax.set_xticks(range(len(cols)),[wrap(c,14) for c in cols],fontsize=9);ax.set_yticks(range(len(t)),[wrap(c,34) for c in t.index],fontsize=9)
    for i in range(len(t)):
        for j in range(len(cols)):ax.text(j,i,str(mat[i,j]),ha='center',va='center',color='white' if mat[i,j]>80 else INK,fontsize=9)
    finish(f,'11_audience_by_platform','Audience coverage is distributed across complementary channels','Cells show activity counts; logarithmic colour shading makes smaller audience groups visible. One primary audience per record; supplementary multi-label tables should be used to examine overlapping coverage.')
    p=tab('Annual');f,ax=plt.subplots(figsize=(10,5.1));bottom=np.zeros(3)
    for c,col in zip(['Central','Local','Dissemination'],[BLUE,TEAL,GOLD]):
        vals=100*p[c]/p.Total;ax.bar(['2024','2025','2026 YTD'],vals,bottom=bottom,color=col,label=c)
        for i,v in enumerate(vals):ax.text(i,bottom[i]+v/2,f'{v:.1f}%',ha='center',va='center',color='white',fontsize=11)
        bottom+=vals
    ax.set_ylabel('Share of annual records (%)');ax.set_ylim(0,108);ax.legend(frameon=False,ncol=3,loc='upper center')
    finish(f,'12_central_local_contributions','Local distribution grows into an equal part of implementation','Register shares are contributions to logged activity, not causal shares of unique reach. Partner counts are sensitive to missing dates and aggregate reporting; amplification is not automatically a duplicate.')
    f,axes=plt.subplots(1,2,figsize=(10,5.1));x=['2024','2025','2026 YTD'];av=q.groupby('year').av_evidence.sum();mp=q.groupby('year').mp4_link.sum()
    for ax,v,lab,col in zip(axes,[av,mp],['All audiovisual-evidence records','Instagram MP4-linked records'],[BLUE,TEAL]):
        b=ax.bar(x,v,color=col);annotate(ax,b);ax.set_title(lab,fontsize=12);ax.set_ylim(0,max(v)*1.25);ax.set_ylabel('Records')
    finish(f,'13_audiovisual_development','Short-form distribution expands the audiovisual repertoire','Record counts are not unique productions or verified views. MP4 evidence is available for the 2025–2026 Instagram export; a 2024 zero means no MP4-linked records, not absence of video production.')
    k=pd.read_csv(ROOT/'KPI_matrix.csv');f,axes=plt.subplots(1,2,figsize=(12,5.2),gridspec_kw={'width_ratios':[1,1.8]})
    ax=axes[0];ax.barh(['Website'],[327.492],color=TEAL);ax.axvline(100,color=GOLD,ls='--',label='Target = 100%');ax.text(327.492,.0,' 327.5%',va='center',fontweight='bold');ax.set_xlim(0,430);ax.set_xlabel('User-supplied views / target (%)');ax.legend(frameon=False,loc='lower right')
    s=k.Assessment_status.value_counts();labels=[wrap(v.replace(' based on documented evidence',''),32) for v in s.index];b=axes[1].barh(labels,s.values,color=[TEAL,GOLD,BLUE,GRAY][:len(s)] if len(s)<=4 else [GOLD,TEAL,BLUE,GRAY,'#8C6D9E'][:len(s)]);annotate(axes[1],b,horizontal=True);axes[1].set_xlim(0,max(s.values)*1.3);axes[1].set_xlabel('Number of commitments (29 assessed)')
    finish(f,'14_grant_kpi_assessment','Website scale exceeds target; other commitments require distinct evidence','Status counts are not a weighted compliance score. Functional equivalents, estimates and exact-format delivery are distinguished in the full matrix. Website reporting period and metric alignment remain a final validation item.')
    m=tab('Monthly');m=m[m.month>='2025-01'];e=tab('Metrics_month').set_index('month');f,axes=plt.subplots(2,1,figsize=(11,6.5),sharex=True);x=np.arange(len(m));axes[0].plot(x,m.Total,color=BLUE,marker='o',lw=2);axes[0].set_ylabel('All activity records');vals=[e.loc[v,'Impressions'] if v in e.index else np.nan for v in m.month];axes[1].bar(x,vals,color=TEAL);axes[1].set_ylabel('Labelled LinkedIn\nimpressions');axes[1].set_xticks(x[::2],m.month.iloc[::2],rotation=40,ha='right');axes[1].yaxis.set_major_formatter(FuncFormatter(lambda v,p:f'{v/1000:.0f}k'))
    finish(f,'15_activity_visibility_trends','Publication activity and measured visibility have different coverage','Missing LinkedIn metric months are left blank, not treated as zero. Activity covers all channels, whereas the lower panel is a labelled LinkedIn subset. The figure does not establish a causal relationship.')
    (ROOT/'chart_manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
    print('Created',len(meta),'charts')

if __name__=='__main__':make()
