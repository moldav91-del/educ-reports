"""Check final analytical invariants and the generated Office deliverables."""
import json,math,zipfile,hashlib
from pathlib import Path
import pandas as pd,numpy as np
from openpyxl import load_workbook
from docx import Document
from PIL import Image
from build_analysis import ROOT,SOURCE

def validate():
    d=pd.read_csv(ROOT/'analytical_dataset.csv',keep_default_na=False)
    for c in ['year','estimate_numeric','impressions','views','clicks','interactions','reach_accounts','likes','shares','saves']:d[c]=pd.to_numeric(d[c],errors='coerce')
    q=d[d.eligible_net];tests=[]
    def check(name,condition):
        assert condition,name
        tests.append({'check':name,'passed':True})
    check('All source populations reconciled',len(d)==2855 and d.eligible_gross.sum()==2236 and len(q)==2213)
    check('Gross-minus-net equals listed duplicate reports',int((d.eligible_gross & ~d.eligible_net).sum())==23 and d.duplicate_of.ne('').sum()==23)
    check('Retained records respect snapshot',q.date_start.ge('2024-01-01').all() and q.date_start.le('2026-11-16').all())
    check('Descriptions retained when title is absent',q[q.title.eq('')].description.ne('').all())
    for f in ['Annual','Topic_year','Audience_year','Platform_year','Format_year','Channel_year']:
        a=pd.read_csv(ROOT/(f+'.csv'))
        check(f+' totals reconcile',int(a.Total.sum())==len(q))
    for f in ['Monthly','Quarterly']:
        a=pd.read_csv(ROOT/(f+'.csv'));num=a.select_dtypes(include='number')
        value=int(a.Total.sum()) if 'Total' in a else int(num.to_numpy().sum())
        check(f+' excludes three year-only entries',value==len(q)-3)
    m=pd.read_csv(ROOT/'Matched_period.csv');check('Aligned comparison correct',list(m.Total)==[603,729])
    check('Comparable intervals fully contained',all((str(v)[5:]<='11-16') for v in q[q.matched_2025_2026].date_end))
    e=q[q.impressions.notna()];check('Labelled post cohort correct',len(e)==110 and e.publication_id.nunique()==110)
    check('Reported metric totals correct',e.impressions.sum()==152433 and e.clicks.sum()==7622 and e.interactions.sum()==2921)
    check('Reported views observed independently',e.views.count()==12 and e.views.sum()==698 and q.views.count()==13 and q.views.sum()==3909)
    check('Instagram labelled case retained',q.reach_accounts.sum()==2237 and q.likes.sum()==43 and q.shares.sum()==4 and q.saves.sum()==2)
    check('Legitimate conference contributions retained',q.record_id.isin(['D0167','D0170']).sum()==2)
    check('Different Facebook publications with same generic text retained',q.record_id.isin(['C0141','C0142','C0143','C0144','C0147','C0148']).sum()==6)
    check('Different Instagram stories retained',q.record_id.isin(['L0445','L0446']).sum()==2 and q[q.record_id.isin(['L0445','L0446'])].publication_id.nunique()==2)
    check('Alternative platform URLs retained separately',q.record_id.isin(['L0808','L0809']).sum()==2)
    check('Instagram MP4 evidence correct',q.mp4_link.sum()==153 and q[q.mp4_link].platform.eq('Instagram').all())
    k=pd.read_csv(ROOT/'KPI_matrix.csv');allowed={'Exceeded','Achieved','Likely achieved based on documented evidence','Partially achieved','Not achieved','Insufficient evidence'}
    check('Complete valid KPI statuses',len(k)==29 and set(k.Assessment_status).issubset(allowed))
    check('Website attainment formula correct',abs(k.loc[k.KPI_ID=='K01','Achievement_pct'].iloc[0]-327.492)<1e-9)
    check('Original source workbook hash stable',hashlib.sha256(SOURCE.read_bytes()).hexdigest()==json.loads((ROOT/'summary.json').read_text())['source_sha256'])
    b=load_workbook(ROOT/'deliverables/EDUC_Analytical_Workbook_2024_2026.xlsx',data_only=True)
    check('Workbook sheets present',len(b.sheetnames)==51 and all(x in b for x in ['Evidence_register','KPI_matrix','Analytical','Calendar_analysis','Formula_Audit','Instagram_case']))
    check('Excel cached website attainment',abs(b['KPI_matrix']['E5'].value-327.492)<1e-8)
    check('Excel formula differences are zero',all(b['Formula_Audit'].cell(i,4).value==0 for i in range(5,17)))
    sourcecheck=json.loads((ROOT/'workbook_validation.json').read_text())
    check('All populated original source cells/formulas preserved',sourcecheck['original_cell_values_and_formulas_preserved'] and sourcecheck['source_populated_cells_compared']==29642)
    report=Document(ROOT/'deliverables/EDUC_Comprehensive_Final_Report_2024_2026.docx')
    headings=[p.text for p in report.paragraphs if p.style.name=='Heading 1']
    for i in range(1,18):check('Report section '+str(i)+' present',any(h.startswith(str(i)+'. ') for h in headings))
    check('Dedicated beyond-commitments section present',any('Communication Beyond the Original Commitments' in h for h in headings))
    check('Important charts embedded',len(report.inline_shapes)==13)
    check('15 publication-quality charts exported',len(list((ROOT/'charts').glob('*.png')))==15)
    for p in (ROOT/'charts').glob('*.png'):
        im=Image.open(p);check(p.name+' readable resolution',im.width>=2000 and im.info.get('dpi',(0,0))[0]>=299)
    for p in (ROOT/'deliverables').glob('*.docx'):
        check(p.name+' valid Office archive',zipfile.is_zipfile(p))
    results={'checks':tests,'checks_passed':len(tests),'all_passed':True,'core_records':len(q),'gross_records':int(d.eligible_gross.sum()),'duplicate_reports':23,'website_attainment_pct':327.492,'original_populated_cells_preserved':29642}
    (ROOT/'validation_results.json').write_text(json.dumps(results,indent=2));print('Passed',len(tests),'checks')
    return results

if __name__=='__main__':validate()
