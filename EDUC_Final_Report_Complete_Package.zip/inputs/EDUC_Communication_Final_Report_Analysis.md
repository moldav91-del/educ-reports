# EDUC Communication and Dissemination: Evidence-Based Final Report Analysis
**Reporting periods:** 2024–2026 (cumulative) and 2025–2026 (comparative subset). **Data cut-off:** records available on 16 November 2026.

## Executive assessment
The source registers contain **1,796 date-attributable activity records** within 2024–2026, including **1,064 in 2025–2026**. These are recorded entries, not necessarily unique actions or independently verified reach. The event calendar is excluded from these activity totals pending separate reconciliation.
The dataset documents substantial multi-channel activity, but does not by itself establish fulfilment of all Grant Agreement numeric targets. In particular, estimated persons reached must not be presented as unique reach, page views, subscribers, engagement, or participation without corresponding platform evidence.

## Activity volumes by year and register
| Year | Central | Local | Dissemination | Total |
|---|---:|---:|---:|---:|
| 2024 | 421 | 306 | 5 | 732 |
| 2025 | 149 | 320 | 12 | 481 |
| 2026 | 218 | 342 | 23 | 583 |

## Communication channels, 2024–2026
| Channel (source labels) | Recorded entries |
|---|---:|
| Social media | 795 |
| Website | 321 |
| Newsletter | 253 |
| Media article | 137 |
| Event (Conference;meeting; workshop; internet debate; round table; group discussion) | 72 |
| Print materials (brochure; leaflet; poster; sticker; banner) | 71 |
| Video | 38 |
| None | 23 |
| Interview | 14 |
| Event (Conference, meeting, workshop, internet debate, round table, group discussion) | 13 |
| Conferences | 9 |
| Event | 5 |
| Education and Training events | 5 |
| Press release | 4 |
| Print materials | 2 |

## Social media platforms, 2024–2026
| Platform | Entries |
|---|---:|
| LinkedIn | 325 |
| Instagram | 276 |
| Facebook | 144 |
| YouTube | 18 |
| Not specified / other | 18 |
| Bluesky | 8 |
| TikTok | 3 |
| Twitter | 1 |
| iVoox | 1 |
| Unspecified | 1 |

## Target audiences, 2024–2026
| Recorded target group | Entries |
|---|---:|
| Specific end-user communities | 756 |
| Other | 376 |
| Research Communities | 206 |
| Citizens | 183 |
| Unspecified | 105 |
| EU Institutions | 56 |
| Civil Society | 51 |
| Industry/Business partner | 21 |
| National Authorities | 12 |
| Local Authorities | 10 |
| International organizations (UN, OECD) | 5 |
| International organizations (UN; OECD) | 3 |
| National authorities | 3 |
| Research communities | 1 |
| Civil Sciety | 1 |

## Activity timing: 2025–2026
| Month | Entries |
|---|---:|
| 2025-01 | 58 |
| 2025-02 | 56 |
| 2025-03 | 32 |
| 2025-04 | 38 |
| 2025-05 | 26 |
| 2025-06 | 39 |
| 2025-07 | 25 |
| 2025-08 | 14 |
| 2025-09 | 48 |
| 2025-10 | 47 |
| 2025-11 | 69 |
| 2025-12 | 29 |
| 2026-01 | 87 |
| 2026-02 | 68 |
| 2026-03 | 39 |
| 2026-04 | 49 |
| 2026-05 | 44 |
| 2026-06 | 73 |
| 2026-07 | 63 |
| 2026-08 | 28 |
| 2026-09 | 60 |
| 2026-10 | 41 |
| 2026-11 | 30 |
| 2026-12 | 1 |

## Estimated audience field: interpretation and limitations
| Year | Entries with numeric estimate | Sum of reported estimates (not unique reach) |
|---|---:|---:|
| 2024 | 643 / 732 | 859,530 |
| 2025 | 360 / 481 | 2,928,746 |
| 2026 | 483 / 583 | 3,024,018 |

**Important:** These sums combine heterogeneous self-reported estimates and can contain repeated audiences, duplicate entries, non-comparable metrics, or outliers. They are not independently measured platform reach and should not be published as an EDUC-wide reach KPI without validation.

## Grant Agreement 3.2: commitment-by-commitment assessment
The commitments below are transcribed from the provided Part B, section 3.2 (pp. 65–67). “Not verifiable” means that the present activity register is insufficient to establish achievement; it does not mean the activity was not delivered.

| Commitment | Grant target | Evidence required / assessment |
|---|---|---|
| Website | 75,000 page views | **Not verifiable** from activity records; obtain GA4 page-view total for aligned project period. |
| Newsletter | 1,500 subscribers | **Not verifiable** from newsletter activity count; obtain dated subscriber snapshots and mailing analytics. |
| Print | 30,000 copies overall | **Not verifiable** from print-activity records; require production/distribution evidence. |
| Promotional video | 5,000 views in four years | **Not verifiable** from video entry counts; aggregate actual video analytics with deduplication. |
| Mailing campaigns | 5 per year | **Partially documented** through newsletter and mailing records; classify genuine targeted campaigns separately from routine newsletter issues. |
| Promotion of EDUC offers | 2 offers per month, reaching at least 6,000 students | **Partially documented**; classify unique offers and obtain attributable student reach, not general estimated audience. |
| Annual Forum | 1/year, 2,000 participants | **Not verifiable** from communication entries; use event attendance records and distinguish registrations from attendees. |
| Interactive co-creation | 1/year, 150 participants | **Partially documented** through event descriptions; verify qualifying formats and attendee lists. |
| Social media | 150 views per weekly post | **Not verifiable** from mixed estimated-persons field; use post-level view metrics and assess weekly publishing cadence. |
| Policy papers | 2/year | **Not verifiable** from communications alone; cross-check dated policy publications. |
| Blog | 6 posts/year | **Not verifiable** until website items are classified as implementation blogs. |
| Expert podcast/video | 4/year | **Partially documented** through video/interview records; confirm expert format, unique outputs and release dates. |
| Roundtables | 2/year | **Not verifiable** until events are categorized and unique roundtables confirmed. |
| FOR-EU, stakeholder surveys and relevant national agency venues | 100% participation (as applicable) | **Not verifiable** from activity log; requires denominator of relevant meetings/processes and documented attendance. |
| Local-language communications, partner amplification | Qualitative commitment | **Documented in principle** through partner-level communications; verify language distribution and channel coverage. |
| Student-to-student communication and Friends of EDUC | Qualitative commitment | **Requires targeted evidence** of student-led outputs, governance communications and network development. |
| EU emblem and funding acknowledgement | Prominent and correct use | **Requires compliance audit** of sample website, social, print and event materials. |

## Five strategic objectives: qualitative synthesis
**Awareness:** Broad recorded activity across social, website, newsletters and partner media supports dissemination activity; audience exposure cannot be quantified reliably from this log alone.
**Engagement:** The register captures activities and narrative outcomes, but lacks a consistently labelled interactions/reactions/comments/shares dataset. Do not calculate engagement rate from estimated persons reached.
**Co-creation:** Events and stakeholder engagement are present in the records, but their co-creation character and verified participation need format-level review.
**Sharing results:** Website, media and dissemination entries indicate sharing activity. Distinguish actual project results, deliverables and good-practice transfer from promotional announcements.
**Sustainability:** Partner-level channels and repeated dissemination support institutional embedding; long-term continuation needs evidence of maintained structures, resources and community ownership.

## Method and data-quality caveats
- Activity counts are register rows, not deduplicated campaigns, posts, people or outcomes.
- Date attribution uses Excel serial dates and recognizable day/month/year or ISO-like text dates. Month-only, planned, blank and ambiguous dates require review.
- The Event Calendar is not yet reconciled with event-related activity rows.
- Category labels have been lightly normalized for capitalization and whitespace only; “Other” is not a meaningful audience segment.
- Data are incomplete for engagement rates, actual page views, subscriber counts, verified attendance, publication copies and compliance.
- 2026 figures are partial-year and should not be compared as full-year equivalents without an aligned cut-off.
- Avoid double counting central posts amplified locally; measure both gross communication outputs and unique underlying messages separately.

## Recommended final reporting approach
Publish activity volumes as verified register-based outputs, report measured platform analytics separately, and give each Grant Agreement commitment a traceable evidence source, reference period, achievement status and narrative explanation. Update after November–December 2026 records and reconcile the 2025–2026 comparison on matched periods.