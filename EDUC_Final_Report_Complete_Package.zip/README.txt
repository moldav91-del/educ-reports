EDUC II — D9.3 communication and dissemination analysis
Reporting snapshot: 16 November 2026

MAIN DELIVERABLES
1. EDUC_Comprehensive_Final_Report_2024_2026.docx — completed analytical report.
2. EDUC_Analytical_Workbook_2024_2026.xlsx — 51 sheets including the four preserved original worksheets, all source records, classifications, cross-tabulations, KPI matrix and evidence register.
3. charts/ — 15 publication-quality PNG charts (300 dpi); 13 are embedded in the report.
4. EDUC_Evidence_and_Methodology_Annex.docx — full calculations, assumptions, classifications, KPI explanations and evidence register.
PDF reading copies are included as an additional convenience.

HEADLINE RESULTS
2,236 eligible gross records; 23 duplicate reports removed; 2,213 retained records.
Annual retained activity: 776 in 2024; 705 in 2025; 732 to 16 November 2026.
Aligned 1 January–16 November comparison: 603 (2025) to 729 (2026), +20.9%.
Website: user-supplied 245,619 views / 75,000 target = 327.492%; period/property/definition to validate.
Labelled LinkedIn cohort: 110 posts; 152,433 impressions; 7,622 clicks; 2,921 reactions/comments/reposts.
One Instagram case: 3,211 views, 2,237 accounts reached, 43 likes, 4 shares and 2 saves.
The gross heterogeneous audience-value sum is NOT unique reach and must not be added to the labelled analytics.

NAVIGATION
Use START_HERE in the analytical workbook. Filter Analytical eligible_net = TRUE for the core population. C/L/D record IDs retain original row numbers; source_reference cells link to the original worksheets. All 29,642 populated source cells/formulas were checked for preservation. The Event Calendar is complementary and not added to the core activity total.

REPRODUCIBILITY
Original inputs are in inputs/; analytical CSV and evidence tables are in data/; validation checks are in validation/.
Use Python 3.11 or later with reproducibility/requirements.txt dependencies.
Run: python reproducibility/run_all.py
Alternatively supply another source workbook path as its first argument.
The script reads the original input and writes regenerated tables/charts/Office files under reproducibility/; original inputs are not modified. PDF rendering requires LibreOffice and is not part of the Python rebuild.

ASSESSMENT CAUTIONS
Read the report and full KPI matrix for evidence types: measured/labelled analytics, user-supplied analytics, audience estimates, functional equivalents and qualitative evidence. Subscriber/attendance/copy/video-view thresholds are not silently substituted with activity counts. Student exposure is estimated from a single explicitly student-directed channel base, not summed overlapping recipients. Annual and cumulative targets are assessed separately.
